#!/usr/bin/env python3
"""Audit every runtime draft mapping, rollout row, and offline ZIP asset.

Checks chapter-qualified section keys, ordering including supplemental images,
regular local files, package parity and HTTP byte parity. It does not replace
interactive, scientific, accessibility, teacher or browser testing.
"""
from pathlib import Path
import csv, hashlib, json, urllib.request, zipfile
ROOT = Path(__file__).resolve().parent.parent
BASE = ROOT.parent/'eduverse_2d_assets'
js = (ROOT/'src/app.js').read_text()
raw = js.split('const EVRASTER = (() => {',1)[1].split('  const assets = ',1)[1].split('\n};',1)[0]+'\n}'
assets = json.loads(raw)
with (BASE/'ROLLOUT_STATUS.csv').open(encoding='utf-8-sig',newline='') as f:
    rows=list(csv.DictReader(f))
assert len({(r['chapter_id'],r['section']) for r in rows}) == len(rows) == 266
status={(r['chapter_id'],r['section']):r for r in rows if r['asset_generation_status']=='AI_DRAFT_REVIEW_PENDING'}
keys={(chapter,section) for chapter,group in assets.items() for section in group}
assert keys==set(status),(sorted(keys-set(status)),sorted(set(status)-keys))
refs=[]
for chapter,section in sorted(keys):
    row=status[chapter,section]
    assert row['integrated_in_main_app']=='DRAFT_ONLY'
    assert row['toggle_2d_currently_enabled']=='True'
    paths=[chapter+'/'+name for name in assets[chapter][section]]
    assert paths==row['asset_file'].split('; '),(chapter,section,paths,row['asset_file'])
    for path in paths:
        f=ROOT/'assets/2d'/path
        assert f.is_file() and not f.is_symlink(),str(f)
        refs.append('assets/2d/'+path)
assert len(refs)==len(set(refs))==247
zpath=ROOT/'eduverse-publish.zip'
with zipfile.ZipFile(zpath) as z:
    assert z.testzip() is None
    assert set(refs)=={n for n in z.namelist() if n.startswith('assets/2d/') and n.endswith('.jpg')}
    assert z.read('index.html')==(ROOT/'index.html').read_bytes()
    if (ROOT/'publish/index.html').exists():
        assert z.read('index.html')==(ROOT/'publish/index.html').read_bytes()
    assert z.read('review/ROLLOUT_STATUS.csv')==(BASE/'ROLLOUT_STATUS.csv').read_bytes()
    assert z.read('review/CONCEPT_TRACKER_FIRST_PASS.csv')==(ROOT.parent/'eduverse_topic_audit/CONCEPT_TRACKER_FIRST_PASS.csv').read_bytes()
    for ref in refs:
        local=(ROOT/ref).read_bytes();assert z.read(ref)==local
        assert urllib.request.urlopen('http://127.0.0.1:8080/'+ref,timeout=10).read()==local,ref
    assert urllib.request.urlopen('http://127.0.0.1:8080/',timeout=10).read()==z.read('index.html')
print('PASS:',len(keys),'mapped spreads in',len(assets),'chapters;',len(refs),'images; runtime, status, local HTTP and archive bytes match.')
print('Unbuilt spreads:',len(rows)-len(keys),'| Class IX 8.6–8.8 replacements await user review.')
print('Index SHA-256:',hashlib.sha256((ROOT/'index.html').read_bytes()).hexdigest())
print('ZIP SHA-256:',hashlib.sha256(zpath.read_bytes()).hexdigest())
