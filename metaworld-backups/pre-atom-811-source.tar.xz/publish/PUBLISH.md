> **2D draft update — partial coverage.** This package now contains local images under `assets/2d/` and is no longer single-file when using the new 2D previews. Extract the full ZIP, preserving folders. Fifty-nine of 266 audited spreads have unreviewed AI drafts; scientific accuracy, comprehensive topic coverage, bilingual anchored labels and teacher sign-off remain pending. A 390px-wide mobile viewport clips the page; Zoom shows the image, and canvas screenshots may omit the DOM image layer. The remaining 207 spreads do not yet have usable drafts. Details and concept tracking are in `review/`. Full regression and accessibility testing are pending. Historical single-file statements below describe the previous build.

# EduVerse — Publish Guide / प्रकाशन गाइड

**सवाल:** क्या इसे HTML के तौर पर publish किया जा सकता है, या Docker चाहिए?
**जवाब:** **हाँ, सीधे HTML के तौर पर publish होगा — Docker की ज़रूरत बिल्कुल नहीं।**
`index.html` एक **self-contained static file** है (under 5 MB in the launch build — one offline HTML incl. 29 inert JSON chapter packs): Three.js r187, QR generator,
Devanagari font और सभी 26 chapters + live 3D engine उसी एक फ़ाइल में embedded हैं। कोई backend, database, API key,
build step, Node server या runtime download नहीं — verified: **0 external `src`/`href`**, कोई
absolute path नहीं, `localStorage` सिर्फ़ progress के लिए। इसलिए कोई भी **static host** काफ़ी है
(Netlify, GitHub Pages, Cloudflare Pages, Vercel, school nginx/Apache, USB/pen-drive)।

Docker सिर्फ़ **optional** है — अगर स्कूल अपना server/container खुद चलाना चाहे। Public publish
के लिए Docker अनावश्यक overhead है।

> **English:** No Docker needed. It is one static HTML file. Drag-and-drop it onto any static
> host; the same file also runs from `file://` on a classroom laptop with no internet at all.
> Docker is only an optional way to serve that same file yourself.

> **Launch audit (2026-11-03):** three.js is upgraded from the deprecated r150 UMD
> build to a **tree-shaken r187 IIFE** (0 deprecation warnings, smaller bundle), every
> every inline script is **SHA-256 hash-pinned in a strict CSP** (script-src has no `unsafe-inline`; style-src allows inline dynamic DOM styles only),
> Playwright QA is pinned to **1.65.0 / Node 24 LTS / `npm audit` = 0**, and
> `_headers` + `nginx.conf` ship HSTS, frame-deny, nosniff, referrer,
> permissions, COOP and CORP headers. Run `make launch` before uploading; it rebuilds,
> republishes, cold-loads the gzip bundle three times, probes XSS/headers/performance,
> and fails closed through `tools/launch_gate.py`. Evidence: `qa/launch_result.json`,
> `qa/launch_gate_result.json`, `docs/LAUNCH_AUDIT.md`.

> **Master Engine step 3 note (2026-11-03):** the same single file now also ships the
> **canonical O3 Class X Light lab** (`?o3=1` or the `◉ O3 rays` toggle). It reuses the one
> shared WebGLRenderer and adds no asset, no CDN, no GLB/GLTF and no backend. Default views
> are unchanged; Prompts 4 and 5 are now shipped; nothing is deferred.
> Design: `../docs/O3_LIGHT.md` and `../docs/PROJECTOR_MODE.md`.
>
> **Master Engine step 4 note (2026-11-03):** the same single file now also ships
> **Projector Mode** (`?projector=1`, `#btnProjector` or `Alt+P`) and the
> canonical `EVDICT` bilingual dictionary for every chip, tag, button, title,
> toast, tab and control. EN/HI/EN+HI changes DOM text only; the same canvas and
> WebGLRenderer survive. High contrast 21:1, 95%+ canvas, straight board, exact
> credit, 0 external refs. Default views are unchanged. Nothing is deferred; all five prompts are shipped.
> Design: `../docs/PROJECTOR_MODE.md`.
>
> **R6 note (2026-11-07):** the same single file now also renders a **second live Three.js
> scene** into the right page of every lesson (real 3D, animated, no CDN, no extra asset).
> Nothing changes for publishing: still one static HTML file, still 0 external refs, still
> works from `file://` with no internet. The `◈` button toggles ULTRA 3D, `30ft` toggles the
> back-row plate, `◐` toggles the studio theme. See `../docs/REAL_3D_PIPELINE.md`.

---

## 0. Package contents / पैकेज में क्या है

| File | काम |
|---|---|
| `index.html` | **पूरा ऐप** — यही publish करना है (बाकी सब optional helpers) |
| `.nojekyll` | GitHub Pages को Jekyll processing skip करने के लिए |
| `_headers` | Netlify/Cloudflare Pages के लिए cache + security headers |
| `PUBLISH.md` | यह गाइड |
| `Dockerfile`, `nginx.conf`, `compose.yaml` | **optional** — अपना container चलाने के लिए |
| `../eduverse-publish.zip` | Netlify Drop / direct-upload के लिए drag-and-drop ज़िप |

---

## 1. सबसे तेज़ public publish (Drag & Drop, ~30 सेकंड)

1. **Netlify Drop** खोलें: <https://app.netlify.com/drop>
2. `../eduverse-publish.zip` (या `publish/` फ़ोल्डर) को खींचकर छोड़ें।
3. मिल गया `https://<name>.netlify.app` — **HTTPS automatic**, तुरंत live।

यही काम करने वाले विकल्प: **Cloudflare Pages → Direct Upload**, **Vercel** (`npx vercel --prod`
`publish/` से), **Surge** (`npm i -g surge && cd publish && surge .`), **GitHub Pages** (नीचे)।
किसी में भी Docker/build command नहीं लगाना।

> Cloudflare/Netlify में "Build command" खाली रखें, "Publish directory" = `.` (folder upload) या
> ज़िप upload करें। कोई `npm install` नहीं।

---

## 2. GitHub Pages (free, permanent)

```bash
cd /home/user/metaworld/publish
git init
git add index.html .nojekyll _headers PUBLISH.md
git commit -m "Publish EduVerse Ch4 — offline 3D textbook"
git branch -M main
git remote add origin https://github.com/<YOUR-USER>/<YOUR-REPO>.git
git push -u origin main
```

फिर repo → **Settings → Pages → Deploy from a branch → `main` / `/ (root)` → Save**।
URL: `https://<YOUR-USER>.github.io/<YOUR-REPO>/` (HTTPS free)। `.nojekyll` पहले से मौजूद है,
इसलिए Jekyll फ़ाइल को बिगाड़ेगा नहीं।

---

## 3. स्कूल का अपना server / LAN (nginx, Apache, या simple Python)

```bash
# simplest — school LAN, no internet needed
cd /home/user/metaworld/publish
python3 -m http.server 8080 --bind 0.0.0.0
# students open http://<school-server-ip>:8080/index.html
```

nginx पर सिर्फ़ फ़ाइल रख दें:

```nginx
server {
  listen 80;
  server_name eduverse.school.local;
  root /var/www/eduverse;
  index index.html;
  location / { try_files $uri $uri/ /index.html; }
  location = /index.html { add_header Cache-Control "no-cache"; }
}
```

```bash
scp publish/index.html user@school-server:/var/www/eduverse/index.html
```

Internet-facing server पर **HTTPS** ज़रूर लगाएँ (Caddy / Let's Encrypt) — नीचे कारण है।

---

## 4. Docker — **optional**, सिर्फ़ अगर खुद container चाहिए

```bash
cd /home/user/metaworld/publish
docker compose up -d --build     # → http://localhost:8081
```

`compose.yaml` host port `8081` → nginx `:80` map करता है (8081 इसलिए कि workspace preview 8080
पर पहले से चल रहा है); `nginx.conf` gzip + hash-pinned security headers + method allow-list + no-cache on the HTML + SPA fallback देता है; digest-pinned image build-time `nginx -t` से validate होती है।
Production में आगे Caddy/Traefik reverse proxy लगाकर TLS दें:

```bash
docker run -d -p 80:80 -p 443:443 --name caddy \
  -v $PWD/Caddyfile:/etc/caddy/Caddyfile -v caddy_data:/data caddy:2
# Caddyfile:
# eduverse.yourschool.org { reverse_proxy localhost:8081 }
```

**Docker publish का ज़रिया नहीं, सिर्फ़ serve करने का तरीका है** — ऊपर वाले static hosts उसी
`index.html` को बिना container के, free HTTPS के साथ देते हैं।

---

## 5. HTTPS क्यों चाहिए (QR / phone / clipboard)

Teacher Desk के QR **current URL** से deep link बनाते हैं:
`location.href.split("?")[0] + "?world=...&spread=..."` — इसलिए कोई absolute path नहीं है और
site चाहे root पर हो या `/repo/` subpath पर, QR अपने आप सही URL बनाता है।

| Feature | `file://` / `http://` | `https://` (static hosts) |
|---|---|---|
| 3D book, 26 live chapters / 253 spreads, quiz, bilingual, projector view | ✅ | ✅ |
| QR code दिखना / download | ✅ | ✅ |
| Phone camera से QR खोलना, clipboard copy, speech | सीमित (browser policy) | ✅ |
| Progress (`localStorage`) | ✅ | ✅ |

उदाहरण deep link (oxidation, §4.3.2):
`https://YOUR-SITE/index.html?world=c10_carbon&spread=9`

---

## 6. Publish के बाद 2-मिनट की जाँच

1. साइट खोलें → book **सीधा / level** दिखे (▣), dock ऊपर न चढ़े।
2. Top bar में `EN + हिंदी` default हो; `हिंदी` / `English` दोनों चुनें, कोई `□□□` न दिखे।
3. `⛶` से full-stage, `⤢` से **Reader space** (दोनों निचले panels छुप जाते हैं और किताब पूरी चौड़ाई में फैल जाती है), `◧` / `◨` से अलग-अलग panel, `◉` से angled 3D, section picker में 2 chapters · 26 spreads · 32 bilingual quiz items।
4. Tools → Teacher Desk → 16 QR; एक QR खोलें → सही spread खुले।
5. DevTools → Network: **सिर्फ़ 1 document request**, कोई external domain न हो; Console errors = 0।

Automated check (Playwright 1.65.0 पहले से `qa/pwlib` में है; Node 24 LTS use करें):

```bash
cd /home/user/metaworld/qa
PUB_URL="https://YOUR-SITE/index.html?world=c10_carbon&spread=9" node publish_smoke.js
# या local copy:
node publish_smoke.js
```

---

## 7. नया build निकालने पर (update)

```bash
cd /home/user/metaworld
make launch                  # build + publish + 3 cold loads + security/perf + gate + verify
# या सिर्फ़ artefact refresh:
python3 make_publish.py      # rebuild → publish/index.html + CSP headers → fresh zip + sha256
```

`make launch` **local deterministic gate** है: dependency pins, `npm audit`, vendor hashes,
hash-pinned CSP, deployment headers, environment inventory, XSS probes, 8 visual/dashboard/pilot gates,
gzip load times, 0 console warnings/deprecations और publish parity सब fail-closed check होते हैं।
यह local PASS public deployment का प्रमाण नहीं है: host, DNS, TLS, CDN/WAF, credentials और
production validation अभी supply नहीं हुए हैं। Target मिलने के बाद ही नई `index.html` upload करें
(headers `_headers` में भी हैं)।

## 7a. Environment variables / secrets / deployment config

| Category | Value |
|---|---|
| Production runtime env vars | **none** |
| Build-time env vars | **none required** |
| QA-only env vars | `COMBOS`, `QA_URL`, `PUB_URL` — optional, non-secret; `NODE_PATH` / `PLAYWRIGHT_BROWSERS_PATH` are sandbox infrastructure paths only |
| API keys / tokens / `.env` / service accounts | **0** |
| Backend / database / REST endpoint | **0** |
| `Dockerfile` | digest-pinned `nginx:1.30.6-alpine`, `nginx -t` at build, healthcheck |
| `compose.yaml` | `read_only`, `cap_drop: ALL`, `no-new-privileges`, PID/log limits, no secrets |
| `_headers` / `nginx.conf` | hash-pinned CSP, HSTS, DENY, nosniff, referrer, permissions, COOP/CORP, no-cache |

`GEMINI_PROMPT` UI में दिखने वाला JSON-authoring template है, कोई credential नहीं।

---

## 8. Known limits (publish से पहले जान लें)

- WebGL चाहिए (Chrome/Edge/Firefox/Safari, कोई पुराना locked-down browser नहीं)।
- Phone AR/camera HTTPS मांगता है; QR deep links खुद बिना HTTPS भी काम करते हैं अगर phone उसी
  network पर हो।
- PDF upload/Compiler browser में चलता है — कोई server-side OCR/AI call नहीं (AI सिर्फ़ JSON
  authoring pattern है)।
- Documentation: पूरा PRD / TRD / UI-UX / App flow / Data &amp; backend schema / QA / ADR set repository root के `DOCS.md` और `docs/` में है — जानबूझकर इसे static app package में शामिल नहीं किया गया (deploy पर dev docs न जाएँ)। App package सिर्फ़ runnable artefact है।
- Scope: सभी **26 CBSE 2026-27 chapters live** हैं (13 IX *Exploration* + 13 X), 227 generated + 26 curated spreads; 3 labelled reference packs ⚙ Tools में (`SYLLABUS_2026_27.md`)।
- Progress / theme / panels / board-text / ultra — पाँच non-PII `localStorage` keys — per-browser हैं; कोई central student database, cookie या telemetry नहीं।

**Bottom line:** static artefact local deterministic gates में PASS है, लेकिन public deployment
अभी नहीं हुआ है। पहले host, DNS/TLS, CDN/WAF policy, credentials और rollback/validation evidence
तय करें; उसके बाद `index.html` upload करें। Docker की ज़रूरत तभी है जब आप खुद container में
server चलाना चाहें; `make launch` का local PASS final owner sign-off नहीं है।

---

## R3 note

The static package is still **one `index.html`, no Docker required**. It now contains all 26
CBSE 2026-27 chapters and is correspondingly larger (see `PROJECT_MANIFEST.json`). Full
documentation, the syllabus ledger and the coverage validator live in the repository root,
intentionally outside the static package. **Copyright / Developer : Paras Pranav**.

## R7 — biology 3D (current)

The figure opposite biology text is now **NCERT anatomy**, not a generic
orbits-and-spheres decoration: 21 declarative models, per-spread text-aligned
routing, two aligned bilingual label columns, and a precision 2D view from the
same spec. All 73 biology spreads pass `qa/r7_bio_result.json`; full gate:
`docs/BIOLOGY_3D.md`, `qa/architecture_result.json` (release R7).

## R8 — state capsule on a static host

The offline bundle needs no server: `?state=<base64url>` is decoded entirely in
the browser by `EVFSM.decode()` and applied atomically through local adapters.
Nothing is posted, fetched or stored on a backend; legacy `localStorage` keys are
still honoured. See [../docs/STATE_MACHINES.md](../docs/STATE_MACHINES.md) and
[../qa/state_machines.json](../qa/state_machines.json).

## Master Engine — step 1 of 5

The offline bundle also carries the `EVENGINE` factory layer
(`BioEngine` / `ChemEngine` / `PhysEngine`). It creates no extra WebGL context,
no network request and no asset load; it is pure `THREE.Group` scene graphs
driven by validated bilingual JSON. See
[../docs/ENGINE_FACTORIES.md](../docs/ENGINE_FACTORIES.md) and
[../qa/engine_contract.json](../qa/engine_contract.json).

## Master Engine — step 2 of 5 (current)

`EVPACK` (generic JSON chapter packs for ANY class/subject), `EVSTATE` (ONE
shared state machine for `activePartId` + `activeSceneId`) and `EVBIND` provide a
strict two-way UI↔3D binding: HTML chips + an English/Hindi definition panel, a
global `THREE.Raycaster` hook, 15% dim + pulse on selection, and perfect cleanup
on chapter unmount. Parts mode is opt-in (`?parts=1` or the ◈ Parts toggle), so
the shipped default R3–R8 view is unchanged. Steps 3-5 are now shipped; nothing is deferred. See [../docs/CHAPTER_BINDING.md](../docs/CHAPTER_BINDING.md) and
[../qa/chapter_bind_result.json](../qa/chapter_bind_result.json).

## Master Engine — step 4 of 5

`EVDICT` owns every `en / hi / both` UI value and `EVPROJ` owns the opt-in
presentation state. Projector Mode hides the student bar, Tools, HUD and dock,
fills the viewport with the one shared canvas, and shows a compact 21:1 black-on-
white toolbar with language, pager, exit, keyboard hint and exact credit. No new
asset, no CDN, no GLB/GLTF, no backend, no second canvas or context. See
[../docs/PROJECTOR_MODE.md](../docs/PROJECTOR_MODE.md) and
[../qa/projector_result.json](../qa/projector_result.json).

## Atomic Structure first draft batch

Sections 8.1–8.4 are opt-in unreviewed conceptual AI drafts, not scientifically approved images. The generic discharge tube is not the exact Thomson apparatus and does not demonstrate electron charge by itself; Thomson’s model is historical and superseded. Zoom captions include contextual cautions in English and Hindi. Anchored bilingual labels, complete topic coverage, and teacher approval remain pending. Extract the entire ZIP to preserve image paths. Default is 3D.

## Rutherford section 8.5 draft

8.5 adds a conceptual reconstruction with three provisional bilingual anchored labels. It is not the historical apparatus and does not show the scattering results. Detector geometry and scientific accuracy need subject review; teacher approval remains pending.

## Electron distribution section 8.7

8.7 has a schematic neutral argon example 2, 8, 8 with provisional anchored bilingual labels, shown over an AI-generated laboratory background. It is not a photograph of an atom and does not illustrate all first-18 distributions. The misleading 8.7 shell text and shared occupied-shell readout were corrected. Existing chapter sliders still allow fractional atomic numbers; the shell readout rounds to the nearest integer, while other readouts may show fractional values. Subject/teacher review remains pending.

## Bohr model section 8.6

8.6 is an unapproved conceptual historical Bohr schematic of ground-state hydrogen on an AI-generated laboratory backdrop. One electron occupies K; higher depicted levels are empty. Bilingual K, L, M, N and electron anchors are provisional. It is static and does not change when the atomic-number slider moves. It is not a photograph or a literal modern electron orbit, and absorption/emission transitions are not shown. Scientific and teacher review remain pending.

## Atomic and mass number section 8.8

8.8 is an unapproved sodium-23 schematic on an AI-generated laboratory backdrop: 11 protons, 12 neutrons, atomic number Z = 11 and mass number A = 23. The 11 electrons of a neutral atom are described but not pictured. The bilingual labels and nucleus model need scientific and teacher review. It is a static example and does not follow the chapter sliders; existing sliders can still show fractional atomic or neutron numbers.

## Isotopes and isobars section 8.9

8.9 is an unapproved static conceptual model of C-12, C-14 and N-14, with programmatically counted red protons and blue neutrons and provisional bilingual anchored labels, over a blurred AI-generated laboratory scene. C-12 and C-14 are isotopes; C-14 and N-14 are isobars. Models are not photographs of atoms, do not change with sliders and do not cover isotope applications. Science and teacher review remain pending; the existing source wording about dating and medicine needs review. The existing fractional atomic-number/neutron sliders are unchanged.

## Valency and combining capacity section 8.10

8.10 has two unapproved AI conceptual physical-prop images with manually anchored bilingual labels: methane (carbon valency 4, hydrogen 1) and water (oxygen valency 2, hydrogen 1). They depict covalent examples only, not actual molecular photographs; geometry and labels require expert review. The stills do not follow the sliders and do not illustrate ionic bonding, zero valency or all valency cases. Use the image counter or Zoom next button to view both.
