/* ==========================================================================
   EduVerse — Application controller
   Views: Meta World · Book · Chapter Compiler · World Spec · Quiz · Research
   ========================================================================== */

const EV = {
  lang: "both", view: "world", world: null, compiled: null, extraChapters: [],
  progress: {}, quizAnswers: {}, demo: false, precision: false, locked: {},
  panels: { left: true, right: true }, theme: "classroom", boardText: "detail", ultra: false,
  lastTouched: 0, lastModel: null, toastTimer: null
};
const $ = id => document.getElementById(id);
/* Launch audit: only https: links may become hrefs; javascript:/data: are inert. */
function safeHref(u) {
  try {
    const p = new URL(String(u || ""), location.href);
    return p.protocol === "https:" ? p.href : "#";
  } catch (e) { return "#"; }
}
function loadProgress() {
  EVFSM.transition("persistence", "LOAD", {});
  try { EV.progress = JSON.parse(localStorage.getItem("eduverse-progress-v1") || "{}"); }
  catch (e) { EV.progress = {}; EVFSM.transition("persistence", "FAIL", {}); }
}
function saveProgress() {
  EVFSM.transition("persistence", "WRITE", {});
  try { localStorage.setItem("eduverse-progress-v1", JSON.stringify(EV.progress)); EVFSM.transition("persistence", "SAVED", {}); }
  catch (e) { EVFSM.transition("persistence", "FAIL", {}); }
}
function pkey(w, sp) { return (w ? w.id : "none") + "::" + (sp ? sp.id : "0"); }
function pget(w, sp) { const k = pkey(w, sp); return EV.progress[k] || (EV.progress[k] = { locked: false, answer: null, flap: false, stamped: false, touched: 0 }); }
/* R8: the dock's two booleans are ONE four-valued state in EVFSM. */
function panelState() {
  return !EV.panels.left && !EV.panels.right ? "reader"
       : !EV.panels.left ? "leftHidden" : !EV.panels.right ? "rightHidden" : "both";
}
function predictionState(pg) {
  return pg.stamped ? "stamped" : pg.flap ? "flapOpen" : pg.locked ? "locked"
       : (pg.answer !== null && pg.answer !== undefined) ? "answered" : "unanswered";
}
function html(el, s) {
  if (!el) return;
  el.innerHTML = s;
  /* Prompt 4: every dynamic HTML island is re-keyed from the canonical dictionary. */
  if (typeof EVDICT !== "undefined") EVDICT.apply(el, EV.lang);
}
function uiTxt(k, legacy) {
  return (typeof EVDICT !== "undefined") ? EVDICT.get(k, EV.lang, legacy) : legacy;
}
function toastKey(k, legacy, kind) { toast(uiTxt(k, legacy), kind); }
/* A keyed inline span for hidden tool screens and the help modal. html() and
   setLanguage() both call EVDICT.apply(), so the text follows EN/HI/EN+HI. */
function keyedSpan(k, legacy) {
  return `<span data-i18n="${esc(k)}">${esc(uiTxt(k, legacy))}</span>`;
}

/* ------------------------------------------------------------------ chrome */
const NAV = [
  { id: "world", icon: "◎" }, { id: "book", icon: "▤" }, { id: "compiler", icon: "⚙" },
  { id: "spec", icon: "{}" }, { id: "quiz", icon: "✓" }, { id: "research", icon: "⌕" }, { id: "teacher", icon: "▦" }
];
function renderNav() {
  html($("nav"), NAV.map(n => `<button class="nav-item ${EV.view === n.id ? "active" : ""}" data-view="${n.id}"><span>${n.icon}</span>${t(n.id)}</button>`).join(""));
  document.querySelectorAll(".nav-item").forEach(b => b.onclick = () => setView(b.dataset.view));
}
function renderChapterSelect() {
  const sel = $("chapterSelect"); if (!sel) return;
  const cur = EV.world ? EV.world.id : "";
  const list = CATALOGUE_ALL.filter(c => STUDENT_CHAPTERS.indexOf(c.id) >= 0);
  const opt = c => `<option value="${esc(c.id)}" ${cur === c.id ? "selected" : ""}>${esc(BI(c.title, c.hi))}</option>`;
  const grp = (cls, label) => {
    const rows = list.filter(c => c.cls === cls);
    return rows.length ? `<optgroup label="${esc(label)}">` + rows.map(opt).join("") + `</optgroup>` : "";
  };
  /* CBSE 2026-27: NCERT Exploration IX (13) + rationalised NCERT X (13). */
  let opts = grp("IX", `${uiTxt("ui.class")} IX · ${t("syllabus2627")} · 13`) +
             grp("X", `${uiTxt("ui.class")} X · ${t("syllabus2627")} · 13`);
  /* a deep link / Tools shelf may open an undeveloped chapter — keep it visible in the picker */
  const extra = CATALOGUE_ALL.filter(c => !STUDENT_CHAPTERS.includes(c.id) && c.id === cur);
  if (extra.length) opts += `<optgroup label="${esc(t("otherChapters"))}">` + extra.map(opt).join("") + `</optgroup>`;
  if (EV.extraChapters.length) opts += `<optgroup label="${esc(t("compiled"))}">` + EV.extraChapters.map(c => `<option value="extra:${esc(c.id)}" ${cur === c.id ? "selected" : ""}>✦ ${esc(c.title)}</option>`).join("") + `</optgroup>`;
  html(sel, opts);
  sel.onchange = () => {
    const v = sel.value;
    if (v.indexOf("extra:") === 0) {
      const c = EV.extraChapters.find(x => x.id === v.slice(6));
      if (c) { EV.world = c.world; WORLD.setWorld(c.world, 0); renderTop(); renderChapterList(); setView("book"); }
    } else openChapter(v);
  };
}
/* Section navigator: every live chapter's NCERT sections are one click away.
   Chapters are looked up in CHAPTER_PACKS, so no chapter name is hardcoded. */
function renderSectionSelect() {
  const sel = $("sectionSelect");
  const pack = (typeof CHAPTER_PACKS !== "undefined" && EV.world) ? CHAPTER_PACKS[EV.world.id] : null;
  const sections = pack && pack.sections && pack.sections.length ? pack.sections : null;
  if (!sel || !sections) { if (sel) sel.hidden = true; return; }
  sel.hidden = false;
  const idx = WORLD.index;
  let active = 0;
  sections.forEach((sec, i) => { if (Math.abs(sec.spread - idx) < Math.abs(sections[active].spread - idx)) active = i; });
  html(sel, sections.map((sec, i) =>
    `<option value="${sec.spread}" ${i === active ? "selected" : ""}>${esc(BI(sec.en, sec.hi))}</option>`).join(""));
  sel.onchange = () => WORLD.jumpTo(+sel.value);
}
function renderChapterList() {
  const groups = [{ label: t("class9"), cls: "IX" }, { label: t("class10"), cls: "X" }];
  let s = "";
  groups.forEach(g => {
    s += `<div class="chapter-group"><div class="cg-label">${esc(g.label)}</div>`;
    CATALOGUE_ALL.filter(c => c.cls === g.cls).forEach(c => {
      const active = EV.world && EV.world.chapter === c.id;
      s += `<button class="chapter-item ${active ? "active" : ""}" data-ch="${c.id}">
        <span class="ci-dot" style="background:${c.color}"></span>
        <span class="ci-text"><b>${esc(BI(c.title, c.hi))}</b><small>${t(c.subject)} · ${c.cls}</small></span></button>`;
    });
    s += `</div>`;
  });
  if (EV.extraChapters.length) {
    s += `<div class="chapter-group"><div class="cg-label">${esc(t("compiled"))}</div>`;
    EV.extraChapters.forEach(c => {
      s += `<button class="chapter-item ${EV.world && EV.world.id === c.id ? "active" : ""}" data-extra="${esc(c.id)}"><span class="ci-dot" style="background:${c.color}"></span><span class="ci-text"><b>${esc(c.title)}</b><small>${esc(c.source)}</small></span></button>`;
    });
    s += `</div>`;
  }
  html($("chapterList"), s);
  renderChapterSelect();
  document.querySelectorAll("[data-ch]").forEach(b => b.onclick = () => openChapter(b.dataset.ch));
  document.querySelectorAll("[data-extra]").forEach(b => b.onclick = () => {
    const c = EV.extraChapters.find(x => x.id === b.dataset.extra);
    if (c) { EV.world = c.world; WORLD.setWorld(c.world, 0); renderTop(); renderChapterList(); setView("book"); }
  });
}
function renderTop() {
  const w = EV.world;
  $("topTitle").textContent = w ? BI(w.title, w.titleHi) : t("world");
  $("topMeta").textContent = w ? `${w.board} · ${uiTxt("ui.class")} ${w.cls} · ${w.spreads.length} ${t("spreads")} · ${w.source}` : t("tagline");
  $("statSpreads").textContent = w ? w.spreads.length : "—";
  $("statStamps").textContent = stampsFor(w);
  if ($("langSelect")) $("langSelect").value = EV.lang;
  syncBoardUI();
  $("railHeading").textContent = t("chapterShelf");
  $("worldTip").textContent = t("worldHint");
  /* Meta-world title follows the active chapter (26 chapters, no hardcoded Ch4). */
  const pack = w ? CHAPTER_PACKS[w.id] : null;
  if ($("worldEyebrow")) $("worldEyebrow").textContent = w
    ? `CBSE 2026-27 · NCERT SCIENCE · ${uiTxt("ui.classUpper")} ${w.cls} · ${w.source}` : t("ui.worldEyebrow");
  if ($("worldH1")) $("worldH1").textContent = w ? BI(w.title, w.titleHi) : t("ui.worldH1");
  if ($("worldSub")) $("worldSub").textContent = w
    ? `${w.spreads.length} ${t("spreads")} · ${t("ui.worldSpreads")} ${t(w.subject)}`
    : t("ui.worldSub");
  if ($("worldChips")) {
    const chips = (pack && pack.sections ? pack.sections.slice(0, 5) : []);
    $("worldChips").innerHTML = chips.map(sec => {
      const en = sec.en || "", hi = sec.hi || sec.title_hi || en;
      const key = (typeof EVDICT !== "undefined") ? EVDICT.auto(en, hi) : "";
      return `<span${key ? ` data-i18n="${esc(key)}" data-i18n-en="${esc(en)}" data-i18n-hi="${esc(hi)}"` : ""}>${esc(key ? EVDICT.get(key, EV.lang) : BI(en, hi))}</span>`;
    }).join("");
  }
  $("brand").querySelector(".brand-name").textContent = t("brand");
  if ($("btnCompileTop")) $("btnCompileTop").textContent = t("compile");
  if ($("btnEnter")) $("btnEnter").textContent = t("enterWorld") + " " + uiTxt("ui.enterArrow");
  if ($("btnHome")) $("btnHome").classList.toggle("active", EV.view === "world");
  if ($("btnBookTop")) $("btnBookTop").classList.toggle("active", EV.view === "book");
  if ($("langSelect")) $("langSelect").value = EV.lang;
  /* Prompt 4: dynamic chrome is re-keyed after every render. */
  if (typeof EVDICT !== "undefined") EVDICT.apply(document, EV.lang);
}
function stampsFor(w) { if (!w) return 0; return w.spreads.filter(sp => (EV.progress[pkey(w, sp)] || {}).stamped).length; }
function setView(v) {
  EVFSM.transition("view", "ENTER", { to: v });
  EV.view = v;
  const three = v === "world" || v === "book";
  $("screen").hidden = three;
  $("worldHud").hidden = v !== "world";
  $("bookHud").hidden = v !== "book";
  /* Academic library: a class drawer never survives a view change. */
  if (window.EVLIB && v !== "world") EVLIB.close();
  $("stage").classList.toggle("screen-mode", !three);
  const toolView = ["compiler", "spec", "research", "teacher"].includes(v);
  /* tool screens are full-screen: never leave the drawer floating over them */
  if ($("toolsDrawer")) $("toolsDrawer").hidden = true;
  EVFSM.observe("toolsDrawer", "closed", "app.js:setView");
  if (v === "world") { WORLD.setView("world", false); EV.precision = false; applyPrecision();
    EVFSM.transition("precision", "FORCE_OFF", { view: "world" }); }
  if (v === "book") { if (!EV.world) openChapter("c10_carbon"); WORLD.setView("book", false); renderLesson(); renderMeters(); renderPageBar(); }
  if (!three) html($("screenInner"), renderScreen(v));
  renderNav(); renderTop(); renderChapterList();
  if (typeof EVBIND !== "undefined") EVBIND.onView();
  if (typeof O3LAB !== "undefined") O3LAB.onView();
  if (typeof EVPROJ !== "undefined") EVPROJ.onView();
  if ($("btnTools")) $("btnTools").classList.remove("active");
  if (v === "compiler") bindCompiler();
  if (v === "spec") bindSpec();
  if (v === "quiz") bindQuiz();
  if (v === "teacher") bindTeacher();
}
/* Universal Home: return to the Class IX/X dashboard from any view, any
   full-screen tool screen and from the preserved 3D shelf. The original
   setView / HUD / EV.view contracts are untouched. */
function goHome() {
  /* projector has no top bar; leave it first so its chrome is restored */
  if (typeof EVPROJ !== 'undefined' && EVPROJ.active) EVPROJ.setActive(false);
  /* a help / about modal covers the top bar; dismiss it on the way Home */
  document.querySelectorAll('.modal').forEach(n => n.remove());
  if (window.EVLIB) { EVLIB.close(); EVLIB.setLibrary(true); }
  setView("world");
}
function openChapter(id) {
  EVFSM.transition("navigation", "OPEN_CHAPTER", { to: id + "::0", known: CATALOGUE_ALL.some(c => c.id === id) });
  /* Prompt 5 · parse only THIS chapter's inert JSON pack on demand. */
  if (typeof EVLAZY !== "undefined") EVLAZY.onChapter(id);
  if (WORLD.plate2d) WORLD.setPlate2D(false);
  EVRASTER.deactivate();
  EV.world = getWorld(id);
  WORLD.setWorld(EV.world, 0);
  /* Prompt 2 · a chapter change is an UNMOUNT + fresh MOUNT of the shared
     selection state (perfect cleanup of the previous chapter's 3D group). */
  if (typeof EVBIND !== "undefined") EVBIND.onChapter(id, 0);
  if (typeof O3LAB !== "undefined") O3LAB.onChapter(id, 0);
  renderTop(); renderChapterList(); setView("book");
  flash();
}
function flash() { const f = $("flash"); f.classList.remove("go"); void f.offsetWidth; f.classList.add("go"); }
function toast(msg, kind) {
  const el = $("toast"); el.textContent = msg; el.className = "toast show " + (kind || "");
  clearTimeout(EV.toastTimer); EV.toastTimer = setTimeout(() => el.className = "toast", 2600);
}
function download(name, text) {
  const b = new Blob([text], { type: "application/json" }), u = URL.createObjectURL(b);
  const a = document.createElement("a"); a.href = u; a.download = name; a.click();
  setTimeout(() => URL.revokeObjectURL(u), 1500);
}

/* --------------------------------------------------------------- lesson card */
function renderLesson() {
  const w = EV.world, sp = w && w.spreads[WORLD.index]; if (!w || !sp) return;
  const hi = EV.lang === "hi", pg = pget(w, sp);
  const pr = P(sp), raw = sp.predict || { q: "", options: [], a: 0 }, rawHi = sp.predictHi;
  const title = BI(sp.title, sp.titleHi), concept = BI(sp.concept, sp.conceptHi), explain = BI(sp.explain, sp.explainHi);
  const opts = pr.options.map((o, i) => {
    let cls = "popt";
    if (pg.locked) { cls += i === pr.a ? " correct" : (i === pg.answer ? " wrong" : " dim"); }
    else if (pg.answer === i) cls += " picked";
    const label = EV.lang === "both" && rawHi ? BX(raw.options[i], rawHi.options[i]) : esc(o);
    return `<button class="${cls}" data-opt="${i}" ${pg.locked ? "disabled" : ""}><b>${String.fromCharCode(65 + i)}</b><span>${label}</span></button>`;
  }).join("");
  const formula = sp.formula ? `<div class="lc-formula"><span>${esc(sp.formula.label)}</span><strong>${esc(sp.formula.eq)}</strong><small>${esc(sp.formula.note)}</small></div>` : "";
  const vocab = VOC(sp).length ? `<div class="lc-vocab">${VOC(sp).slice(0, 4).map(v => `<div><b>${esc(v[0])}</b> — ${esc(v[1])}</div>`).join("")}</div>` : "";
  const rawV = sp.vocab || [], rawVHi = sp.vocabHi || [];
  const terms = VOC(sp).slice(0, 3).map((v, i) => `<span title="${esc(v[1])}"><b>${EV.lang === "both" && rawVHi.length ? BX(rawV[i] && rawV[i][0], rawVHi[i] && rawVHi[i][0]) : esc(v[0])}</b></span>`).join(" · ");
  html($("lessonCard"), `
    <div class="lc-head"><span>§ ${esc(sp.section)} · ${esc(t("predict"))}</span>
      <span><button class="btn ghost tiny" id="btnNarrate" title="${esc(t("narrate"))}" data-i18n-title="narrate" data-i18n-aria="narrate">◖</button>
      <span class="stamp ${pg.stamped ? "earned" : ""}" id="stampBadge">${pg.stamped ? "★ " + esc(t("stamp")) : "☆"}</span></span></div>
    <h2>${EV.lang === "both" ? BX(sp.title, sp.titleHi) : esc(title)}</h2>
    <div class="lc-terms"><small>${esc(t("keyTerms"))}:</small> ${terms}</div>
    <p class="lc-concept">${esc(concept)}</p>
    <div class="predict">
      <div class="predict-q">${EV.lang === "both" && rawHi ? BX(raw.q, rawHi.q) : esc(pr.q)}</div>
      <div class="predict-opts">${opts}</div>
      <div class="predict-foot">
        <button class="btn small ${pg.locked ? "done" : "primary"}" id="lockPredict" ${pg.locked ? "disabled" : ""}>${pg.locked ? "✓ " + esc(t("check")) : esc(t("check"))}</button>
        <small>${esc(t("predictHint"))}</small>
      </div>
      <div class="flap ${pg.flap ? "open" : ""}" id="flap">
        <div class="flap-under"><b>${esc(t("flap"))}</b><p>${EV.lang === "both" ? BX(sp.explain, sp.explainHi) : esc(explain)}</p></div>
        <div class="flap-front">✦ &nbsp; ${esc(t("flapClosed"))}</div>
      </div>
    </div>`);
  document.querySelectorAll("[data-opt]").forEach(b => b.onclick = () => {
    if (pg.locked) return;
    pg.answer = +b.dataset.opt; EVFSM.transition("prediction", pg.answer !== null ? "CHOOSE" : "CHANGE", {}, pkey(w, sp));
    EVFSM.observe("prediction", predictionState(pg), "app.js:renderLesson", pkey(w, sp));
    saveProgress(); renderLesson();
  });
  $("lockPredict").onclick = () => {
    if (pg.answer === null) { toastKey("toast.choose", "Choose an option first", "warn"); return; }
    const lr = EVFSM.transition("prediction", "LOCK", { answer: pg.answer }, pkey(w, sp));
    if (EVFSM.strict() && !lr.ok) { toast(lr.reason, "warn"); return; }
    pg.locked = true; EVFSM.observe("prediction", "locked", "app.js:lockPredict", pkey(w, sp));
    saveProgress(); renderLesson(); renderMeters();
    toastKey(pg.answer === P(sp).a ? "toast.good" : "toast.locked",
      pg.answer === P(sp).a ? "Good prediction! Now verify it on the model." : "Prediction locked — now test it on the model.", "ok");
  };
  $("flap").onclick = () => {
    if (!pg.locked) { toastKey("toast.lockFirst", "Lock your prediction before lifting the flap", "warn"); return; }
    const fr = EVFSM.transition("prediction", "FLAP", { locked: pg.locked }, pkey(w, sp));
    if (EVFSM.strict() && !fr.ok) { toast(fr.reason, "warn"); return; }
    pg.flap = !pg.flap; EVFSM.observe("prediction", predictionState(pg), "app.js:flap", pkey(w, sp));
    saveProgress(); $("flap").classList.toggle("open", pg.flap);
  };
  if ($("btnNarrate")) $("btnNarrate").onclick = () => narrate(title + ". " + concept + ". " + explain);
}
function narrate(text) {
  if (!("speechSynthesis" in window)) { toastKey("toast.speechOff", "Speech synthesis unavailable in this browser", "warn"); return; }
  speechSynthesis.cancel();
  const u = new SpeechSynthesisUtterance(text); u.lang = EV.lang === "en" ? "en-IN" : "hi-IN"; u.rate = 0.92;
  speechSynthesis.speak(u); toastKey("toast.narrating", "Narrating…");
}

/* --------------------------------------------------------------- meter card */
function renderMeters() {
  const w = EV.world, sp = w && w.spreads[WORLD.index]; if (!w || !sp) return;
  const block = BLOCKS[sp.scene.type] || BLOCKS.showcase, ctrls = blockControls(block, sp);
  const st = WORLD.getState(), model = evalModel(sp, st.params), pg = pget(w, sp);
  EV.lastModel = model;
  const meters = (model.readouts || []).map((r, i) => `
    <div class="meter"><div class="meter-track"><div class="meter-fill" data-ro="${i}" style="height:${clampPct(r.pct)}%"></div></div>
    <div class="meter-label">${esc(r.label)}</div><div class="meter-value" data-rv="${i}">${esc(r.value)}<small>${esc(r.unit)}</small></div></div>`).join("");
  const sliders = ctrls.map(c => `
    <div class="ctrl"><label for="c_${esc(c.id)}">${esc(c.label)} <b id="cv_${esc(c.id)}">${esc(st.params[c.id])}</b> ${esc(c.unit)}</label>
    <input type="range" id="c_${esc(c.id)}" min="${c.min}" max="${c.max}" step="${(c.max - c.min) / 100}" value="${st.params[c.id]}" data-cid="${esc(c.id)}"></div>`).join("");
  const ch = sp.challenge;
  const chText = ch ? BI(ch.text, ch.textHi) : uiTxt("ui.challengeDefault");
  const done = ch ? checkChallenge(sp, model, pg) : (st.touched.size >= 2 && pg.locked);
  html($("meterCard"), `
    <div class="mc-head"><span>${esc(t("meters"))}</span><small>${esc(block.label)}</small></div>
    <div class="meters">${meters}</div>
    <div class="controls">${sliders}</div>
    <div class="challenge ${done ? "done" : ""}" id="challengeBox"><span>${esc(t("challenge"))}</span><b>${esc(chText)}</b><em>${done ? "✓" : "○"}</em></div>
    <div class="mc-progress"><span>${esc(t("touchHint"))}</span><div class="touch-dots" id="touchDots"></div></div>
    <div class="mc-actions">
      <button class="btn ghost small" id="btnPrecision">${esc(t("precision"))}</button>
      <button class="btn ghost small" id="btnReset">${esc(t("reset"))}</button>
      <button class="btn primary small" id="btnDemo">▶ ${esc(t("demo"))}</button>
    </div>`);
  document.querySelectorAll("[data-cid]").forEach(inp => inp.oninput = () => WORLD.setParam(inp.dataset.cid, +inp.value, "slider"));
  $("btnPrecision").onclick = () => { EV.precision = !EV.precision; applyPrecision(); renderMeters(); };
  $("btnReset").onclick = () => { WORLD.resetExperiment(); toastKey("toast.reset", "Experiment reset"); renderMeters(); };
  $("btnDemo").onclick = toggleDemo;
  renderTouchDots(); updateReadouts(model);
}
function clampPct(v) { return Math.max(2, Math.min(100, Number(v) || 2)); }
function renderTouchDots() {
  const st = WORLD.getState(), n = Math.min(6, Math.max(3, st.touched.size));
  const dots = []; for (let i = 0; i < 6; i++) dots.push(`<i class="${i < st.touched.size ? "on" : ""}"></i>`);
  const el = $("touchDots"); if (el) html(el, dots.join(""));
}
function updateReadouts(model) {
  (model.readouts || []).forEach((r, i) => {
    const f = document.querySelector(`[data-ro="${i}"]`), v = document.querySelector(`[data-rv="${i}"]`);
    if (f) f.style.height = clampPct(r.pct) + "%";
    if (v) v.innerHTML = esc(r.value) + `<small>${esc(r.unit)}</small>`;
  });
  const st = WORLD.getState(), sp = EV.world.spreads[WORLD.index];
  const chBox = $("challengeBox");
  if (chBox) {
    const done = sp.challenge ? checkChallenge(sp, model, pget(EV.world, sp)) : (st.touched.size >= 2 && pget(EV.world, sp).locked);
    chBox.classList.toggle("done", done);
    const em = chBox.querySelector("em"); if (em) em.textContent = done ? "✓" : "○";
  }
  Object.keys(st.params).forEach(k => { const b = $("cv_" + k); if (b) b.textContent = st.params[k]; });
  if (EV.precision) renderPrecision(model, sp);
  maybeStamp(model);
}
function maybeStamp(model) {
  const w = EV.world, sp = w && w.spreads[WORLD.index]; if (!sp) return;
  const pg = pget(w, sp), st = WORLD.getState();
  const challengeOK = sp.challenge ? checkChallenge(sp, model, pg) : (st.touched.size >= 2 && pg.locked);
  const all = pg.locked && challengeOK && st.touched.size >= 2;
  if (all && !pg.stamped) {
    EVFSM.transition("prediction", "STAMP", { locked: pg.locked, challengeOK: challengeOK, touched: st.touched.size }, pkey(w, sp));
    EVFSM.observe("prediction", "stamped", "app.js:maybeStamp", pkey(w, sp));
    pg.stamped = true; saveProgress();
    const badge = $("stampBadge");
    if (badge) { badge.className = "stamp earned"; badge.textContent = "★ " + t("stamp"); }
    renderTop(); toast("★ " + uiTxt("toast.stamped"), "ok");
    flash();
    if (cbVoice()) { /* small confirmation only */ }
  }
}
function cbVoice() { return false; }
function applyPrecision() {
  EVFSM.observe("precision", EV.precision ? "on" : "off", "app.js:applyPrecision");
  $("precision2d").hidden = !EV.precision;
  $("btnPrecision") && ($("btnPrecision").textContent = EV.precision ? t("precisionBack") : t("precision"));
  if (EV.precision) { const st = WORLD.getState(); renderPrecision(st.model || evalModel(EV.world.spreads[WORLD.index], st.params), EV.world.spreads[WORLD.index]); }
  else WORLD.resize();
}
function renderPrecision(model, sp) {
  const W = 900, H = 560;
  const bars = (model.readouts || []).map((r, i) => {
    const y = 60 + i * 58, pct = clampPct(r.pct);
    return `<text x="30" y="${y + 4}" class="pl">${esc(r.label)}</text>
      <rect x="250" y="${y - 15}" width="480" height="26" rx="13" fill="#1d3550"/>
      <rect x="250" y="${y - 15}" width="${480 * pct / 100}" height="26" rx="13" fill="${["#4ad6ff", "#7ee0b8", "#ffc46b", "#ff9b8a"][i % 4]}"/>
      <text x="742" y="${y + 4}" class="pv">${esc(r.value)} ${esc(r.unit)}</text>`;
  }).join("");
  let schematic = "";
  const type = sp.scene.type;
  /* cbse-interactive-lab discipline: the accessible 2D plate and the live 3D
     opposite page are rendered from ONE declarative biology spec. */
  const bioSpec = (typeof BIO3D !== "undefined") ? BIO3D.spec(EV.world, sp) : null;
  if (bioSpec) {
    schematic = BIO3D.svg2D(bioSpec, model, esc);
  } else if (type === "particles" || type === "diffusion") {
    const n = Math.round(12 + (Number(model.temp || model.mixing || 20) / 100) * 40), pts = [];
    const rnd = G3.seeded(55);
    for (let i = 0; i < n; i++) pts.push(`<circle cx="${(430 + rnd() * 420).toFixed(0)}" cy="${(300 + rnd() * 200).toFixed(0)}" r="6" fill="#4ad6ff" opacity=".8"/>`);
    schematic = `<rect x="415" y="285" width="450" height="230" rx="10" fill="none" stroke="#4ad6ff" stroke-width="2"/>${pts.join("")}`;
  } else if (type === "ph") {
    const px = 30 + Number(model.pH) / 14 * 840;
    schematic = `<defs><linearGradient id="phg"><stop offset="0" stop-color="#e4584f"/><stop offset=".5" stop-color="#62d6b0"/><stop offset="1" stop-color="#4d7ad6"/></linearGradient></defs>
      <rect x="30" y="430" width="840" height="34" rx="17" fill="url(#phg)"/>
      <polygon points="${px},420 ${px - 12},398 ${px + 12},398" fill="#fff"/><text x="${px}" y="490" text-anchor="middle" class="pv">pH ${esc(model.pH)}</text>`;
  } else if (type === "plot") {
    const d = []; for (let i = 0; i <= 60; i++) { const x = 30 + i * 14; const y = 500 - (100 / (1 + Math.exp(-(i * 1.67 - 50) / 12))) * 3.4; d.push(`${i ? "L" : "M"}${x},${y}`); }
    schematic = `<path d="${d.join(" ")}" fill="none" stroke="#4ad6ff" stroke-width="3"/><circle cx="${30 + Number(model.x) / 100 * 840}" cy="${500 - Number(model.y) / 100 * 340}" r="10" fill="#ffc46b"/>`;
  } else if (type === "cell") {
    schematic = `<circle cx="660" cy="400" r="120" fill="none" stroke="#7ee0b8" stroke-width="3"/><circle cx="660" cy="400" r="46" fill="#a47ad0" opacity=".8"/>
      ${[[590, 350, 18], [730, 350, 18], [620, 470, 16], [710, 460, 16]].map(o => `<circle cx="${o[0]}" cy="${o[1]}" r="${o[2]}" fill="#ffc46b"/>`).join("")}
      <text x="660" y="540" text-anchor="middle" class="pl">${esc(model.found || 0)} / 6 ${esc(uiTxt("ui.partsIdentified"))}</text>`;
  } else if (typeof LIGHT_TYPES !== "undefined" && LIGHT_TYPES.indexOf(type) >= 0) {
    /* Different visual grammar: a flat ray diagram, not a carbon chain. */
    const v = Number(model.v || (model.power !== undefined ? model.power * 8 : 0));
    const m = Number(model.m || 0), i = Number(model.i || 0), n = Number(model.n || 1);
    const px = clamp(430 + v * 7, 70, 830), py = clamp(400 - m * 90, 120, 520);
    const virtual = px > 430 && (model.virtual === true || (model.real === false && type !== "slab"));
    schematic = `<line x1="60" y1="400" x2="860" y2="400" stroke="#9fb9cf" stroke-width="2"/>
      <rect x="424" y="245" width="12" height="310" rx="5" fill="#4ad6ff" opacity=".65"/>
      <line x1="120" y1="290" x2="430" y2="290" stroke="#ffc46b" stroke-width="3"/>
      <line x1="430" y1="290" x2="${px.toFixed(0)}" y2="${py.toFixed(0)}" stroke="${virtual ? "#9fd8ff" : "#7ee0b8"}" stroke-width="3" ${virtual ? 'stroke-dasharray="9 7"' : ""}/>
      <line x1="120" y1="290" x2="430" y2="400" stroke="#ffc46b" stroke-width="3"/>
      <line x1="430" y1="400" x2="${px.toFixed(0)}" y2="${py.toFixed(0)}" stroke="${virtual ? "#9fd8ff" : "#7ee0b8"}" stroke-width="3" ${virtual ? 'stroke-dasharray="9 7"' : ""}/>
      <circle cx="${px.toFixed(0)}" cy="${py.toFixed(0)}" r="11" fill="#ffc46b"/>
      <text x="460" y="205" class="pl">${esc(type === "slab" ? "i " + i + "°  →  r " + (model.r || 0) + "°  ·  n " + n : type === "lenspower" ? "P = " + (model.power || 0) + " D" : "v = " + (model.v || 0) + " cm  ·  m = " + m)}</text>
      <text x="460" y="545" class="pl">${esc(virtual ? uiTxt("ui.virtualImage") : uiTxt("ui.realImage"))}</text>`;
  } else if (typeof CARBON_TYPES !== "undefined" && CARBON_TYPES.indexOf(type) >= 0) {
    const n = clamp(Math.round(Number(model.n || model.carbons || model.ringAtoms || 3)), 1, 8);
    const pts = [], bonds = [];
    for (let i = 0; i < n; i++) {
      const x = 470 + i * (400 / Math.max(1, n - 1)), y = 400;
      pts.push(`<circle cx="${x.toFixed(0)}" cy="${y}" r="22" fill="#35424e" stroke="#4ad6ff" stroke-width="3"/><text x="${x.toFixed(0)}" y="${y + 7}" text-anchor="middle" fill="#eaf6ff" font-size="18" font-weight="bold">C</text>`);
      if (i) bonds.push(`<line x1="${(x - 400 / Math.max(1, n - 1)).toFixed(0)}" y1="${y}" x2="${x.toFixed(0)}" y2="${y}" stroke="#9fb9cf" stroke-width="5"/>`);
    }
    schematic = bonds.join("") + pts.join("") +
      `<text x="670" y="480" text-anchor="middle" class="pl">${esc(model.formula || "C" + n)}</text>` +
      `<text x="670" y="515" text-anchor="middle" class="pl">${esc(model.name || model.product || model.allotrope || uiTxt("ui.carbonChain"))}</text>`;
  } else if (type === "atlas") {
    /* Same declarative spec as the 3D pop-up, drawn as an accessible 2D plate. */
    const fig = sp.scene.fig || {}, L = (fig.labels || []).slice(0, 8), n = Math.max(1, L.length);
    const cyc = ["#4ad6ff", "#7ee0b8", "#ffc46b", "#5d8ad6", "#a878c8", "#ff9b8a"];
    let parts = "";
    L.forEach((lab, i) => {
      const x = 440 + (i - (n - 1) / 2) * (420 / Math.max(1, n - 1));
      parts += `<rect x="${(x - 48).toFixed(0)}" y="330" width="96" height="76" rx="12" fill="${cyc[i % cyc.length]}" opacity="${i === Math.round(Number(model.active || 0)) ? ".95" : ".55"}"/>`;
      parts += `<text x="${x.toFixed(0)}" y="374" text-anchor="middle" class="pl">${esc(String(lab))}</text>`;
      if (i) parts += `<line x1="${(x - 420 / Math.max(1, n - 1) + 48).toFixed(0)}" y1="368" x2="${(x - 48).toFixed(0)}" y2="368" stroke="#9fb9cf" stroke-width="3"/>`;
    });
    schematic = `<text x="440" y="285" class="pl">${esc(fig.kind || uiTxt("ui.diagram"))} · ${esc(sp.figHi || sp.fig || "")}</text>${parts}
      <text x="440" y="470" class="pl">${esc((sp.scene.readouts || []).map(r => r.label).join("  ·  "))}</text>`;
  } else {
    schematic = `<rect x="430" y="360" width="130" height="140" rx="8" fill="#4ad6ff" opacity=".55"/>
      <rect x="590" y="300" width="130" height="200" rx="8" fill="#7ee0b8" opacity=".55"/>
      <rect x="750" y="390" width="110" height="110" rx="8" fill="#ffc46b" opacity=".55"/>`;
  }
  html($("precision2d"), `<svg viewBox="0 0 ${W} ${H}" preserveAspectRatio="xMidYMid meet">
    <style>.pl{fill:#a9c7e0;font:18px Georgia,serif}.pv{fill:#eaf6ff;font:bold 20px Georgia,serif}</style>
    <rect width="${W}" height="${H}" fill="#0e1d30" rx="18"/>
    <text x="30" y="36" fill="#4ad6ff" font-family="Georgia" font-size="22" font-weight="bold">${esc(t("precision"))} · ${esc((BLOCKS[type] || BLOCKS.showcase).label)}</text>
    ${bars}${schematic}
    <text x="30" y="545" fill="#7090ad" font-family="Georgia" font-size="15">${esc(bioSpec ? uiTxt("ui.precisionBio") : uiTxt("ui.precisionNote"))}</text>
  </svg>`);
}

/* --------------------------------------------------------------- page bar */
/* Teacher-selected 2D / 3D: an explicit alternative, never a GPU fallback.
   Phase 1 is c9_cell only; 3D is the default for every chapter and spread. */
function setPlateView(v) {
  const on = v === "2d";
  if (on && !WORLD.plate2dAvailable(EV.world)) {
    toastKey("plate2d.soon", "This 2D chapter is in a later phase.");
    return;
  }
  /* Idempotent: clicking the already-selected segment must not create a
     rejected FSM transition. The adapter and WORLD setter stay authoritative. */
  if (WORLD.plate2d === on) { if (!on) EVRASTER.deactivate(); renderPageBar(); return; }
  if (on && EVRASTER.has(EV.world, EV.world && EV.world.spreads[WORLD.index])) EVRASTER.activate();
  if (!on) EVRASTER.deactivate();
  EVFSM.transition("figureMode", on ? "PLATE_2D" : "PLATE_2D_OFF",
    { plate2dAvailable: WORLD.plate2dAvailable(EV.world), classroom: EV.theme === "classroom" });
  WORLD.setPlate2D(on);
  EVRASTER.frame(); // synchronously remove any draft when leaving 2D
  EVFSM.observe("figureMode", WORLD.plate2d ? "plate2d" : "3d", "app.js:setPlateView");
  renderPageBar();
  if (on && EVRASTER.enabled) toast("AI draft · science and labels need review / AI प्रारूप · समीक्षा शेष");
  else toastKey(on ? "plate2d.on" : "plate2d.off",
    on ? "Labelled 2D plate selected" : "Live 3D model restored");
}
/* Local, explicitly opted-in, unapproved raster draft. This is an HTML image
   layered over the 2D page: never sample file:// pixels into the WebGL canvas. */
const EVRASTER = (() => {
  const assets = {
  "c9_cell": {
    "2.1": [
      "2-01-discovery.jpg"
    ],
    "2.2": [
      "2-02-plant-animal.jpg"
    ],
    "2.3": [
      "2-03-prokaryote-eukaryote.jpg"
    ],
    "2.4": [
      "2-04-membrane.jpg"
    ],
    "2.5": [
      "2-05-wall-vacuole.jpg"
    ],
    "2.6": [
      "2-06-nucleus.jpg"
    ],
    "2.7": [
      "2-07-mitochondria-chloroplast.jpg"
    ],
    "2.8": [
      "2-08-er-golgi-lysosomes.jpg"
    ],
    "2.9": [
      "2-09-cell-division.jpg",
      "2-09-meiosis-supplement.jpg"
    ],
    "2.10": [
      "2-10-biomolecules.jpg",
      "2-10-biomolecules-supplement.jpg"
    ],
    "2.11": [
      "2-11-division-cancer.jpg"
    ]
  },
  "c9_tissues": {
    "3.1": [
      "3-01-what-tissue.jpg"
    ],
    "3.2": [
      "3-02-organisation.jpg"
    ],
    "3.3": [
      "3-03-meristem.jpg"
    ],
    "3.4": [
      "3-04-simple-plant-tissues.jpg"
    ],
    "3.5": [
      "3-05-xylem.jpg"
    ],
    "3.6": [
      "3-06-phloem.jpg"
    ],
    "3.7": [
      "3-07-epithelial.jpg"
    ],
    "3.8": [
      "3-08-connective.jpg"
    ],
    "3.9": [
      "3-09-muscle-nervous.jpg"
    ],
    "3.10": [
      "3-10-musculoskeletal.jpg"
    ],
    "3.11": [
      "3-11-care.jpg"
    ]
  },
  "c9_motion": {
    "4.1": [
      "4-01-reference-frame.jpg"
    ],
    "4.2": [
      "4-02-distance-displacement.jpg"
    ],
    "4.3": [
      "4-03-speed.jpg"
    ],
    "4.4": [
      "4-04-velocity.jpg"
    ],
    "4.5": [
      "4-05-acceleration.jpg"
    ],
    "4.6": [
      "4-06-distance-time.jpg"
    ],
    "4.7": [
      "4-07-velocity-time.jpg"
    ],
    "4.8": [
      "4-08-equations.jpg"
    ],
    "4.9": [
      "4-09-circular-motion.jpg"
    ]
  },
  "c9_mixtures": {
    "5.1": [
      "5-01-homogeneous.jpg"
    ],
    "5.2": [
      "5-02-solutions.jpg"
    ],
    "5.3": [
      "5-03-suspensions.jpg"
    ],
    "5.4": [
      "5-04-colloids.jpg"
    ],
    "5.5": [
      "5-05-mass-percent.jpg"
    ],
    "5.6": [
      "5-06-concentration.jpg"
    ],
    "5.7": [
      "5-07-separation.jpg"
    ],
    "5.8": [
      "5-08-distillation.jpg"
    ],
    "5.9": [
      "5-09-chromatography.jpg"
    ],
    "5.10": [
      "5-10-centrifuge.jpg"
    ]
  },
  "c9_forces": {
    "6.1": [
      "6-01-push-pull.jpg"
    ],
    "6.2": [
      "6-02-effects.jpg"
    ],
    "6.3": [
      "6-03-balanced.jpg"
    ],
    "6.4": [
      "6-04-unbalanced.jpg"
    ],
    "6.5": [
      "6-05-friction.jpg"
    ],
    "6.6": [
      "6-06-inertia.jpg"
    ],
    "6.7": [
      "6-07-momentum.jpg"
    ],
    "6.8": [
      "6-08-third-law.jpg"
    ],
    "6.9": [
      "6-09-momentum-conservation.jpg"
    ]
  },
  "c9_work_energy": {
    "7.1": [
      "7-01-constant-force.jpg"
    ],
    "7.2": [
      "7-02-work-signs.jpg"
    ],
    "7.3": [
      "7-03-kinetic-energy.jpg"
    ],
    "7.4": [
      "7-04-potential-energy.jpg"
    ],
    "7.5": [
      "7-05-work-energy.jpg"
    ],
    "7.6": [
      "7-06-conservation.jpg"
    ],
    "7.7": [
      "7-07-power.jpg"
    ],
    "7.8": [
      "7-08-mechanical-advantage.jpg"
    ],
    "7.9": [
      "7-09-lever.jpg",
      "7-09-second-class-supplement.jpg",
      "7-09-third-class-supplement.jpg",
      "7-09-pulley-supplement.jpg",
      "7-09-movable-pulley-supplement.jpg",
      "7-09-incline-supplement.jpg"
    ]
  },
  "c9_atom": {
    "8.1": [
      "8-01-element-atoms.jpg"
    ],
    "8.2": [
      "8-02-electron-discovery.jpg"
    ],
    "8.3": [
      "8-03-proton-neutron.jpg"
    ],
    "8.4": [
      "8-04-thomson-model.jpg"
    ],
    "8.5": [
      "8-05-rutherford-scattering.jpg"
    ],
    "8.6": [
      "8-06-bohr-shells.jpg"
    ],
    "8.7": [
      "8-07-electron-distribution.jpg"
    ],
    "8.8": [
      "8-08-atomic-mass-number.jpg"
    ],
    "8.9": [
      "8-09-isotopes-isobars.jpg"
    ],
    "8.10": [
      "8-10-methane-valency.jpg",
      "8-10-water-supplement.jpg"
    ]
  }
};
  let enabled = false, identity = '', imageIndex = 0, token = 0, ready = false;
  let currentFiles = [];
  function has(world, sp) { return !!(world && sp && assets[world.id] && assets[world.id][sp.section]); }
  function validContext() {
    return enabled && EV.view === 'book' && EV.world && has(EV.world,EV.world.spreads[WORLD.index]) &&
      WORLD.plate2d && !WORLD.turning && !EV.precision && EV.theme === 'classroom' && !EV.ultra;
  }
  function hide() { const el=$('aiDraftPlate'); if (el) el.hidden=true; }
  function load() {
    const number=++token, el=$('aiDraftPlate'), img=$('aiDraftImage');
    ready=false; if(el) el.hidden=true;
    const file=currentFiles[imageIndex]; if(!file || !img) return;
    const views={
      '7-09-lever.jpg':['First-class lever','प्रथम श्रेणी उत्तोलक'],
      '7-09-second-class-supplement.jpg':['Second-class lever','द्वितीय श्रेणी उत्तोलक'],
      '7-09-third-class-supplement.jpg':['Third-class lever','तृतीय श्रेणी उत्तोलक'],
      '7-09-pulley-supplement.jpg':['Fixed pulley','स्थिर घिरनी'],
      '7-09-movable-pulley-supplement.jpg':['Movable pulley','चल घिरनी'],
      '7-09-incline-supplement.jpg':['Inclined plane','आनत तल'],
      '8-10-methane-valency.jpg':['Methane: carbon valency 4, hydrogen valency 1','मीथेन: कार्बन की संयोजकता 4, हाइड्रोजन की 1'],
      '8-10-water-supplement.jpg':['Water: oxygen valency 2, hydrogen valency 1','पानी: ऑक्सीजन की संयोजकता 2, हाइड्रोजन की 1']
    };
    const v=views[file], sp=EV.world.spreads[WORLD.index];
    const description=v ? BI(v[0],v[1]) : BI(sp.title,sp.titleHi);
    const atomNotes={
      '8-01-element-atoms.jpg':['Conceptual copper lattice; atomic inset is not to scale or a micrograph.','ताँबे की जालक संरचना का काल्पनिक चित्र; परमाणु का बड़ा रूप न वास्तविक अनुपात में है, न सूक्ष्मचित्र है।'],
      '8-02-electron-discovery.jpg':['Conceptual discharge tube, not Thomson’s exact apparatus. This image alone does not demonstrate electron charge or beam deflection.','विसर्जन नली का कल्पनात्मक चित्र, थॉमसन का वास्तविक उपकरण नहीं। यह अकेला चित्र इलेक्ट्रॉन के आवेश या किरण के विक्षेप को प्रदर्शित नहीं करता।'],
      '8-03-proton-neutron.jpg':['Conceptual nucleus; sphere colors are not an assigned proton/neutron key, and particle counts are not verified.','नाभिक का कल्पनात्मक चित्र; गोलों के रंग प्रोटॉन या न्यूट्रॉन की निश्चित पहचान नहीं हैं और कणों की संख्या सत्यापित नहीं है।'],
      '8-04-thomson-model.jpg':['Historical Thomson model, since superseded; not the modern nuclear model.','थॉमसन का ऐतिहासिक मॉडल, जिसे बाद में बदला गया; यह आधुनिक नाभिकीय मॉडल नहीं है।'],
      '8-05-rutherford-scattering.jpg':['Conceptual reconstruction with provisional labels for alpha source, gold foil and detector screen; not the original apparatus. Most alpha particles passed through the foil; a few were deflected, very rarely backwards. The still does not show scattering results.','ऐल्फ़ा स्रोत, सोने की पन्नी और संसूचक पर्दे के असत्यापित लेबल वाला कल्पनात्मक पुनर्निर्माण, मूल उपकरण नहीं। अधिकांश ऐल्फ़ा कण पन्नी से निकल गए; कुछ मुड़े और बहुत कम वापस लौटे। स्थिर चित्र प्रकीर्णन के परिणाम नहीं दिखाता।'],
      '8-06-bohr-shells.jpg':['Historical Bohr schematic: one electron in the K shell of ground-state hydrogen; higher levels are empty in this example. This static illustration does not follow the atomic-number slider. It is not a photograph, to scale, or a literal modern electron path.','बोहर का ऐतिहासिक सांकेतिक चित्र: मूल अवस्था के हाइड्रोजन के K कोश में एक इलेक्ट्रॉन है; इस उदाहरण में ऊपरी स्तर रिक्त हैं। यह स्थिर चित्र परमाणु-क्रमांक स्लाइडर के अनुसार नहीं बदलता। यह फ़ोटो, वास्तविक अनुपात या आधुनिक इलेक्ट्रॉन-पथ नहीं है।'],
      '8-07-electron-distribution.jpg':['Schematic neutral argon, Z 18: K has 2 electrons, L 8 and M 8. For the first 18 elements M has at most 8 electrons; its general 2n² capacity is 18. Not a photograph or a scale model.','उदासीन आर्गन का सांकेतिक चित्र, Z 18: K में 2, L में 8 और M में 8 इलेक्ट्रॉन। पहले 18 तत्वों में M में अधिकतम 8 इलेक्ट्रॉन होते हैं; 2n² से M की सामान्य क्षमता 18 है। यह फ़ोटो या वास्तविक अनुपात का मॉडल नहीं है।'],
      '8-08-atomic-mass-number.jpg':['Static sodium-23 example: atomic number Z is 11 protons; mass number A is 23, from 11 protons plus 12 neutrons. A neutral atom has 11 electrons, not shown. The conceptual nucleus is not to scale and does not follow the sliders.','सोडियम-23 का स्थिर उदाहरण: परमाणु क्रमांक Z 11 प्रोटॉन है; द्रव्यमान संख्या A 23 है, यानी 11 प्रोटॉन और 12 न्यूट्रॉन। उदासीन परमाणु में 11 इलेक्ट्रॉन हैं, जो नहीं दिखाए गए। सांकेतिक नाभिक वास्तविक अनुपात में नहीं है और स्लाइडर के अनुसार नहीं बदलता।'],
      '8-09-isotopes-isobars.jpg':['Conceptual static nucleus models: carbon-12 has 6 protons and 6 neutrons; carbon-14 has 6 protons and 8 neutrons; nitrogen-14 has 7 protons and 7 neutrons. Carbon-12 and carbon-14 are isotopes; carbon-14 and nitrogen-14 are isobars. Models are not photographs of atoms and do not follow the sliders.','स्थिर सांकेतिक नाभिक मॉडल: कार्बन-12 में 6 प्रोटॉन और 6 न्यूट्रॉन, कार्बन-14 में 6 प्रोटॉन और 8 न्यूट्रॉन, नाइट्रोजन-14 में 7 प्रोटॉन और 7 न्यूट्रॉन हैं। कार्बन-12 और कार्बन-14 समस्थानिक हैं; कार्बन-14 और नाइट्रोजन-14 समभारिक हैं। मॉडल परमाणुओं की तस्वीरें नहीं हैं और स्लाइडर से नहीं बदलते।'],
      '8-10-methane-valency.jpg':['Conceptual physical teaching model of methane: one carbon and four hydrogen atoms joined by four single covalent bonds. Carbon has valency four and hydrogen one in this example. Static illustration; not a photograph of a molecule and does not follow the sliders.','मीथेन का सांकेतिक शिक्षण मॉडल: एक कार्बन और चार हाइड्रोजन परमाणु चार एकल सहसंयोजक बंधों से जुड़े हैं। इस उदाहरण में कार्बन की संयोजकता चार और हाइड्रोजन की एक है। यह स्थिर चित्र अणु का फ़ोटो नहीं है और स्लाइडर से नहीं बदलता।'],
      '8-10-water-supplement.jpg':['Conceptual physical teaching model of water: one oxygen and two hydrogen atoms joined by two single covalent bonds. Oxygen has valency two and hydrogen one in this example. Static illustration; not a photograph of a molecule and does not follow the sliders.','पानी का सांकेतिक शिक्षण मॉडल: एक ऑक्सीजन और दो हाइड्रोजन परमाणु दो एकल सहसंयोजक बंधों से जुड़े हैं। इस उदाहरण में ऑक्सीजन की संयोजकता दो और हाइड्रोजन की एक है। यह स्थिर चित्र अणु का फ़ोटो नहीं है और स्लाइडर से नहीं बदलता।']
    };
    const note=EV.world.id==='c9_atom' && atomNotes[file];
    $('aiDraftTitle').textContent=description; img.alt=description+(note ? ' — '+BI(note[0],note[1]) : '');
    const src='assets/2d/'+EV.world.id+'/'+file, probe=new Image();
    probe.onload=() => {
      if(number!==token || !validContext()) return;
      img.onload=() => { if(number===token) {ready=true; EVZOOM.refreshDraft();} };
      img.onerror=() => { if(number===token) {ready=false; hide();} };
      img.src=src;
      if(img.complete && img.naturalWidth) {ready=true; EVZOOM.refreshDraft();}
    };
    probe.onerror=() => { if(number===token) {ready=false; hide(); if(!WORLD.vectorPlate2dAvailable(EV.world)) { setPlateView('3d'); toast('Draft image unavailable; live 3D restored / चित्र उपलब्ध नहीं, 3D बहाल'); }} };
    probe.src=src;
    const next=$('aiDraftNext'); if(next) { next.hidden=currentFiles.length<2; next.textContent=(imageIndex+1)+' / '+currentFiles.length; }
  }
  /* Map the 708 x 610 CSS rectangle exactly onto the perspective-projected
     four corners of the existing printed page, without a second renderer. */
  function matrix(p) {
    if(!p || p.length!==4 || p.some(q=>!Number.isFinite(q.x)||!Number.isFinite(q.y)||q.z < -1 || q.z > 1)) return null;
    const [p0,p1,p2,p3]=p, dx1=p1.x-p2.x, dx2=p3.x-p2.x, dx3=p0.x-p1.x+p2.x-p3.x;
    const dy1=p1.y-p2.y, dy2=p3.y-p2.y, dy3=p0.y-p1.y+p2.y-p3.y;
    let g=0,h=0; const det=dx1*dy2-dx2*dy1;
    if(Math.abs(dx3)+Math.abs(dy3)>1e-7) { if(Math.abs(det)<1e-7) return null; g=(dx3*dy2-dx2*dy3)/det; h=(dx1*dy3-dx3*dy1)/det; }
    const a=p1.x-p0.x+g*p1.x, b=p3.x-p0.x+h*p3.x;
    const d=p1.y-p0.y+g*p1.y, e=p3.y-p0.y+h*p3.y;
    return 'matrix3d('+[a/708,d/708,0,g/708,b/610,e/610,0,h/610,0,0,1,0,p0.x,p0.y,0,1].join(',')+')';
  }
  function frame() {
    const el=$('aiDraftPlate'); if(!el || !validContext()){
      if(identity) {identity=''; token++; ready=false;}
      hide(); return;
    }
    const sp=EV.world.spreads[WORLD.index], key=EV.world.id+':'+sp.section+':'+EV.lang;
    if(key!==identity) {
      identity=key; imageIndex=0; currentFiles=(assets[EV.world.id]||{})[sp.section]||[];
      $('aiDraftTitle').textContent=BI(sp.title,sp.titleHi);
      $('aiDraftImage').alt=BI(sp.title,sp.titleHi);
      load();
    }
    const transform=matrix(WORLD.draftPlateCorners());
    if(!ready || !transform){el.hidden=true;return;}
    el.style.transform=transform; el.hidden=false;
  }
  function toggle() {
    enabled=!enabled; identity=''; token++; ready=false; hide();
    if(enabled && !WORLD.plate2d) setPlateView('2d');
    else if(!enabled && WORLD.plate2d && !WORLD.vectorPlate2dAvailable(EV.world)) setPlateView('3d');
    renderPageBar(); frame();
  }
  function install() {
    $('aiDraftOpen').onclick=()=>EVZOOM.open();
    $('aiDraftNext').onclick=next;
  }
  function next() { if(currentFiles.length>1){imageIndex=(imageIndex+1)%currentFiles.length;load();} }
  function zoomSource(allowHidden) {
    const el=$('aiDraftPlate'),img=$('aiDraftImage');
    return el && (allowHidden || !el.hidden) && ready && validContext() && img && img.complete && img.naturalWidth ? {src:img.src,kind:'draft2d',alt:img.alt} : null;
  }
  function pageCounter() { return (imageIndex+1)+' / '+currentFiles.length; }
  function activate() { enabled=true; identity=''; }
  function deactivate() { enabled=false; identity=''; token++; ready=false; hide(); }
  return {frame,toggle,install,zoomSource,has,activate,deactivate,next,pageCounter,get multiple(){return currentFiles.length>1;},get enabled(){return enabled;},isVisible(){const el=$('aiDraftPlate');return !!el && !el.hidden;}};
})();
window.EVRASTER = EVRASTER;

/* Enlarged figure: 2D plates are redrawn at 2x; 3D is a one-shot
   high-resolution render using the shared renderer, not a new live canvas. */
const EVZOOM = (() => {
  let overlay = null, returnFocus = null;
  function close() {
    if (!overlay) return;
    const node = overlay; overlay = null; node.remove();
    if (returnFocus && returnFocus.isConnected) returnFocus.focus({ preventScroll: true });
    returnFocus = null;
  }
  function open() {
    if (overlay || EV.view !== "book" || WORLD.turning) return;
    let snapshot;
    try {
      const precision = document.querySelector("#precision2d:not([hidden]) svg");
      snapshot = precision ? { svg: precision.cloneNode(true), kind: "svg" } : (EVRASTER.zoomSource() || WORLD.zoomSnapshot());
    } catch (e) { snapshot = null; }
    if (!snapshot) { toast(uiTxt("zoom.unavailable")); return; }
    returnFocus = document.activeElement;
    overlay = document.createElement("div"); overlay.className = "evzoom"; overlay.dataset.kind=snapshot.kind;
    overlay.innerHTML = `<section class="evzoom-dialog" role="dialog" aria-modal="true" aria-labelledby="zoomTitle"><div class="evzoom-head"><h2 id="zoomTitle" data-i18n="zoom.title"></h2>${snapshot.kind === "draft2d" && EVRASTER.multiple ? `<button type="button" class="evzoom-next" data-i18n-aria="draft.next" data-i18n-title="draft.next">${esc(EVRASTER.pageCounter())} ›</button>` : ""}<button type="button" class="evzoom-close" data-i18n-aria="ui.close" data-i18n-title="ui.close">×</button></div><div class="evzoom-content"><img class="evzoom-image" alt=""></div>${snapshot.kind === "draft2d" ? `<p class="evzoom-caption" aria-live="polite"></p>` : ""}<p class="evzoom-note" data-i18n="${snapshot.kind === "draft2d" ? "draft.labels" : "zoom.snapshot"}" ${snapshot.kind !== "3d" && snapshot.kind !== "draft2d" ? "hidden" : ""}></p></section>`;
    const image = overlay.querySelector("img");
    if (snapshot.svg) { snapshot.svg.classList.add("evzoom-image"); image.replaceWith(snapshot.svg); }
    else { image.src = snapshot.src; image.alt = snapshot.alt || uiTxt("zoom.title"); }
    const caption=overlay.querySelector(".evzoom-caption"); if(caption) caption.textContent=snapshot.alt || "";
    document.body.appendChild(overlay);
    EVDICT.apply(overlay, EV.lang);
    overlay.querySelector(".evzoom-close").onclick = close;
    const nextButton=overlay.querySelector(".evzoom-next"); if(nextButton) nextButton.onclick=()=>EVRASTER.next();
    overlay.addEventListener("click", e => { if (e.target === overlay || e.target.classList.contains("evzoom-content")) close(); });
    overlay.addEventListener("keydown", e => {
      if (e.key === "Escape") { e.preventDefault(); e.stopPropagation(); close(); }
      if (e.key === "Tab") {
        const controls=[...overlay.querySelectorAll("button:not([disabled])")];
        const i=controls.indexOf(document.activeElement);
        if (controls.length && ((!e.shiftKey && i===controls.length-1) || (e.shiftKey && i===0) || i<0)) {
          e.preventDefault(); controls[e.shiftKey ? controls.length-1 : 0].focus();
        }
      }
      if (e.key === "ArrowLeft" || e.key === "ArrowRight") e.stopPropagation();
    });
    overlay.querySelector(".evzoom-close").focus({ preventScroll: true });
  }
  function refreshDraft() {
    if (!overlay || overlay.dataset.kind !== "draft2d") return;
    const data=EVRASTER.zoomSource(true), image=overlay.querySelector(".evzoom-image"), next=overlay.querySelector(".evzoom-next");
    if (!data || !image) return;
    image.src=data.src; image.alt=data.alt;
    const caption=overlay.querySelector(".evzoom-caption"); if(caption) caption.textContent=data.alt;
    if(next) next.textContent=EVRASTER.pageCounter()+" ›";
  }
  return { open, close, refreshDraft };
})();

function renderPageBar() {
  const w = EV.world; if (!w) return;
  const idx = WORLD.index, n = w.spreads.length;
  const dots = w.spreads.map((s, i) => `<button class="pdot ${i === idx ? "on" : ""} ${(EV.progress[pkey(w, s)] || {}).stamped ? "stamped" : ""}" data-jump="${i}" title="${esc(s.title)}">${i + 1}</button>`).join("");
  html($("pageBar"), `
    <button class="btn ghost" id="btnPrev" ${idx === 0 ? "disabled" : ""}>←</button>
    <div class="pdots">${dots}</div>
    <div class="pb-center"><b>${esc(t("spread"))} ${idx + 1} ${esc(t("of"))} ${n}</b><small>§${esc(w.spreads[idx].section)} · ${esc(w.spreads[idx].short)}</small></div>
    <button class="btn primary" id="btnNext" ${idx === n - 1 ? "disabled" : ""}>→</button>
    <div class="plate-view" role="group" aria-label="${esc(uiTxt("plate2d.toggle"))}" data-i18n-aria="plate2d.toggle">
      <button class="btn ghost tiny ${WORLD.plate2d ? "active" : ""}" id="plate2d" data-plate="2d" title="${esc(uiTxt("plate2d.label"))}" data-i18n-title="plate2d.label" data-i18n-aria="plate2d.label" ${WORLD.plate2dAvailable(w) ? "" : "disabled"}>2D</button>
      <button class="btn ghost tiny ${WORLD.plate2d ? "" : "active"}" id="plate3d" data-plate="3d" title="${esc(uiTxt("plate3d.label"))}" data-i18n-title="plate3d.label" data-i18n-aria="plate3d.label">3D</button>
    </div>
    <div class="pager-tools">
      ${EVRASTER.has(w,w.spreads[idx]) ? `<button class="btn ghost tiny ${EVRASTER.enabled ? 'active' : ''}" id="btnAIDraft" type="button" aria-pressed="${EVRASTER.enabled}" data-i18n="draft.button" data-i18n-title="draft.toggle" data-i18n-aria="draft.toggle">${esc(uiTxt("draft.button"))}</button>` : ''}
      <button class="btn ghost tiny" id="btnZoomFigure" type="button" title="${esc(uiTxt("zoom.open"))}" data-i18n-title="zoom.open" data-i18n-aria="zoom.open" data-i18n="zoom.short">${esc(uiTxt("zoom.short"))}</button>
      <button class="btn ghost tiny ${EV.panels.left ? "" : "active"}" data-panel="left" title="${esc(t("panelLeft"))}" data-i18n-title="panelLeft" data-i18n-aria="panelLeft">◧</button>
      <button class="btn ghost tiny ${EV.panels.right ? "" : "active"}" data-panel="right" title="${esc(t("panelRight"))}" data-i18n-title="panelRight" data-i18n-aria="panelRight">◨</button>
      <button class="btn ghost tiny ${(!EV.panels.left && !EV.panels.right) ? "active" : ""}" data-panel="both" title="${esc(t("reader"))}" data-i18n-title="reader" data-i18n-aria="reader">⤢</button>
    </div>`);
  document.querySelectorAll("[data-jump]").forEach(b => b.onclick = () => WORLD.jumpTo(+b.dataset.jump));
  if ($("btnAIDraft")) $("btnAIDraft").onclick = EVRASTER.toggle;
  if ($("btnZoomFigure")) $("btnZoomFigure").onclick = EVZOOM.open;
  const bp = $("btnPrev"), bn = $("btnNext");
  if (bp) bp.onclick = () => WORLD.startTurn(-1);
  if (bn) bn.onclick = () => WORLD.startTurn(1);
  renderSectionSelect();
}
function toggleDemo() {
  const w = EV.world, sp = w && w.spreads[WORLD.index]; if (!sp) return;
  if (EV.demo) { WORLD.stopDemo(); return; }
  const ctrls = blockControls(BLOCKS[sp.scene.type] || BLOCKS.showcase, sp);
  const steps = ctrls.slice(0, 2).flatMap(c => [
    { control: c.id, to: c.max, caption: uiTxt("ui.demoPrefix") + c.label + " → " + uiTxt("ui.maximum") },
    { control: c.id, to: c.min, caption: uiTxt("ui.demoPrefix") + c.label + " → " + uiTxt("ui.minimum") }
  ]);
  EVFSM.transition("demo", "START", { demo: EV.demo });
  WORLD.runDemo(steps);                 /* its initial stopDemo() fires onDemoStop */
  EV.demo = true; $("btnDemo").textContent = "■ " + t("demoStop");
  $("demoCaption").hidden = false;
  EVFSM.observe("demo", "running", "app.js:toggleDemo");
}
function demoStopped() { EVFSM.transition("demo", "STOP", {}); EV.demo = false; const b = $("btnDemo"); if (b) b.textContent = "▶ " + t("demo"); const c = $("demoCaption"); if (c) c.hidden = true; }

/* --------------------------------------------------------------- screens */
function renderScreen(v) {
  if (v === "compiler") return screenCompiler();
  if (v === "spec") return screenSpec();
  if (v === "quiz") return screenQuiz();
  if (v === "research") return screenResearch();
  if (v === "teacher") return screenTeacher();
  return "";
}
function screenHead(title, sub, right, titleKey, subKey) {
  return `<div class="screen-head"><div><div class="eyebrow" data-i18n="ui.eyebrow">${esc(uiTxt("ui.eyebrow"))}</div><h1${titleKey ? ` data-i18n="${esc(titleKey)}"` : ""}>${esc(title)}</h1><p${subKey ? ` data-i18n="${esc(subKey)}"` : ""}>${esc(sub)}</p></div>${right || ""}</div>`;
}
function screenCompiler() {
  const sample = `Matter in Our Surroundings\n\nAnything that has mass and occupies space is called matter. Matter is made up of very small particles. These particles are continuously moving and there are spaces between them.\n\nThe particles of matter attract each other. In solids the forces of attraction are strongest and the particles are closely packed. In liquids they are less closely packed and can flow. In gases the particles are far apart and move randomly at high speed.\n\nDiffusion is the spontaneous intermixing of particles of two different types of matter. The rate of diffusion increases with temperature because particles gain kinetic energy.\n\nEvaporation is a surface phenomenon. Particles at the surface with higher kinetic energy escape into the air, taking latent heat from the remaining liquid, which therefore cools.\n\nChange of state occurs when energy is supplied or removed. Latent heat of fusion and latent heat of vaporisation are absorbed without a change in temperature.`;
  return screenHead(t("compiler"), uiTxt("ui.compilerSub"),
    `<button class="btn ghost" id="btnLoadSample" data-i18n="demo">${esc(t("demo"))}</button>`, "compiler", "ui.compilerSub") + `
  <div class="grid2">
    <div class="card"><div class="card-head"><b>01 · <span data-i18n="source">${esc(t("source"))}</span></b><label class="upload"><span data-i18n="upload">${esc(t("upload"))}</span><input type="file" id="fileInput" accept=".txt,.md,.pdf,.json"></label></div>
      <textarea id="compileText" spellcheck="false" placeholder="${esc(t("paste"))}" data-i18n-placeholder="paste"></textarea>
      <div class="row"><input class="inp" id="compileTitle" placeholder="${esc(uiTxt("ui.chapterTitleOptional"))}" data-i18n-placeholder="ui.chapterTitleOptional">
        <select class="inp" id="compileCls"><option value="IX" data-i18n="ui.classIX">${esc(uiTxt("ui.classIX"))}</option><option value="X" data-i18n="ui.classX">${esc(uiTxt("ui.classX"))}</option></select>
        <select class="inp" id="compileSubject"><option value="chem" data-i18n="ui.chemistry">${esc(uiTxt("ui.chemistry"))}</option><option value="bio" data-i18n="ui.biology">${esc(uiTxt("ui.biology"))}</option><option value="phy" data-i18n="ui.physics">${esc(uiTxt("ui.physics"))}</option></select></div>
      <div class="row"><button class="btn primary" id="btnCompile" data-i18n="compile">⚙ ${esc(t("compile"))}</button><button class="btn ghost" id="btnClearCompile" data-i18n="ui.clear">${esc(uiTxt("ui.clear"))}</button></div>
      <div class="hint" data-i18n="ui.pdfHint">${esc(uiTxt("ui.pdfHint"))}</div>
    </div>
    <div class="card"><div class="card-head"><b>02 · <span data-i18n="validator">${esc(t("validator"))}</span></b><span id="compileCount">—</span></div>
      <div id="compileReport" class="report muted"><span data-i18n="ready">${esc(t("ready"))}</span>.</div>
      <div class="card-head"><b>03 · <span data-i18n="ui.generatedWorldSpec">${esc(uiTxt("ui.generatedWorldSpec"))}</span></b><button class="btn ghost small" id="btnCopySpec" data-i18n="ui.copyJson">${esc(uiTxt("ui.copyJson"))}</button></div>
      <pre id="compileJson" class="json" data-i18n="ui.compiledPlaceholder">${esc(uiTxt("ui.compiledPlaceholder"))}</pre>
      <button class="btn primary wide" id="btnBuildWorld" data-i18n="applySpec" disabled>✦ ${esc(t("applySpec"))}</button>
    </div>
  </div>`;
}
function screenSpec() {
  const w = EV.world || getWorld("c9_matter");
  return screenHead(t("spec"), uiTxt("ui.specSub"),
    `<button class="btn ghost" id="btnPrompt" data-i18n="ui.copyPrompt">${esc(uiTxt("ui.copyPrompt"))}</button>`, "spec", "ui.specSub") + `
  <div class="grid2">
    <div class="card"><div class="card-head"><b>WorldSpec · ${esc(w.title)}</b><span>${w.spreads.length} <span data-i18n="ui.spreadsLabel">${esc(uiTxt("ui.spreadsLabel"))}</span></span></div>
      <textarea id="specText" class="json-edit" spellcheck="false">${esc(JSON.stringify(w, null, 2))}</textarea>
      <div class="row"><button class="btn primary" id="btnValidateSpec" data-i18n="validate">✓ ${esc(t("validate"))}</button>
        <button class="btn ghost" id="btnDownloadSpec" data-i18n="exportSpec">${esc(t("exportSpec"))}</button>
        <label class="upload"><span data-i18n="importSpec">${esc(t("importSpec"))}</span><input type="file" id="specFile" accept=".json"></label></div>
      <div id="specReport" class="report">—</div>
      <button class="btn primary wide" id="btnApplySpec" data-i18n="applySpec">✦ ${esc(t("applySpec"))}</button>
    </div>
    <div class="card"><div class="card-head"><b data-i18n="ui.schemaContract">${esc(uiTxt("ui.schemaContract"))}</b></div>
      <pre class="schema">${esc(`{
  title, titleHi, cls, subject, board, source, color,
  spreads: [{
    id, short, section, title, titleHi,
    concept, conceptHi,
    formula: { label, eq, note },
    vocab: [[term, def], …],
    predict: { q, options[3], a },
    explain, explainHi, fig, tryHint,
    scene: {
      type: particles | diffusion | molecule |
            reaction | ph | cell | osmosis |
            photosynthesis | flow | stack |
            plot | race | showcase,
      params: {},
      challenge: { text, target: {
        key, value, op: gte|lte|near|eq, tol
      }}
    },
    quiz: { q, options, a, why }
  }]
}`)}</pre>
      <div class="card-head"><b data-i18n="ui.productionPrompt">${esc(uiTxt("ui.productionPrompt"))}</b></div>
      <pre class="schema prompt" id="promptBox">${esc(GEMINI_PROMPT)}</pre>
    </div>
  </div>`;
}
function screenQuiz() {
  const w = EV.world || getWorld("c10_carbon"), qs = QZ(w);
  return screenHead(t("chapterQuiz"), `${BI(w.title, w.titleHi)} · ${qs.length} ${uiTxt("ui.questions")} · ${uiTxt("ui.quizSub")}`,
    `<div class="score-badge" id="scoreBadge">—</div>`, "chapterQuiz") + `
  <div class="quiz-list">${qs.map((q, i) => `
    <div class="quiz-item" data-qi="${i}"><div class="qi-num">${String(i + 1).padStart(2, "0")}</div>
      <div><h3>${esc(q.q)}</h3>
      <div class="qi-opts">${q.options.map((o, j) => `<label><input type="radio" name="q${i}" value="${j}"><span>${String.fromCharCode(65 + j)}. ${esc(o)}</span></label>`).join("")}</div>
      <div class="qi-why" id="why${i}" hidden></div></div></div>`).join("")}
  </div>
  <div class="row"><button class="btn primary" id="btnQuizSubmit" data-i18n="quizFinish">${esc(t("quizFinish"))}</button><button class="btn ghost" id="btnQuizRetry" data-i18n="quizRetry">${esc(t("quizRetry"))}</button><span id="quizResult"></span></div>`;
}
function screenResearch() {
  const rows = REPOS.map((r, i) => `<tr class="tier-${r.tier.toLowerCase()}">
    <td><span class="tier ${r.tier.toLowerCase()}">${esc(r.tier)}</span></td>
    <td><a href="${safeHref(r.url)}" target="_blank" rel="noopener noreferrer" referrerpolicy="no-referrer">${esc(r.repo)}</a><small>${esc(r.lang)} · ${esc(r.lic)} · ★${r.stars}</small></td>
    <td>${esc(r.use)}</td><td class="adopt">${esc(r.adopt)}</td></tr>`).join("");
  return screenHead(t("researchTitle"), t("researchSub") + " — " + uiTxt("ui.researchSubExtra"), "", "researchTitle") + `
  <div class="arch-banner"><div class="eyebrow" data-i18n="ui.archBanner">${esc(uiTxt("ui.archBanner"))}</div>
    <p><b data-i18n="ui.notModuleGallery">${esc(uiTxt("ui.notModuleGallery"))}</b> <span data-i18n="ui.archParagraph">${esc(uiTxt("ui.archParagraph"))}</span></p>
  </div>
  <div class="card table-card"><table class="repo-table"><thead><tr><th data-i18n="ui.tier">${esc(uiTxt("ui.tier"))}</th><th data-i18n="ui.repository">${esc(uiTxt("ui.repository"))}</th><th data-i18n="ui.whatItDoes">${esc(uiTxt("ui.whatItDoes"))}</th><th data-i18n="ui.adopted">${esc(uiTxt("ui.adopted"))}</th></tr></thead><tbody>${rows}</tbody></table></div>
  <div class="card"><div class="card-head"><b data-i18n="ui.designRules">${esc(uiTxt("ui.designRules"))}</b></div><div class="rules">
    <div><b data-i18n="ui.rule1">${esc(uiTxt("ui.rule1"))}</b></div>
    <div><b data-i18n="ui.rule2">${esc(uiTxt("ui.rule2"))}</b></div>
    <div><b data-i18n="ui.rule3">${esc(uiTxt("ui.rule3"))}</b></div>
    <div><b data-i18n="ui.rule4">${esc(uiTxt("ui.rule4"))}</b></div>
    <div><b data-i18n="ui.rule5">${esc(uiTxt("ui.rule5"))}</b></div>
    <div><b data-i18n="ui.rule6">${esc(uiTxt("ui.rule6"))}</b></div>
    <div><b data-i18n="ui.rule7">${esc(uiTxt("ui.rule7"))}</b></div>
  </div></div>`;
}

/* ------------------------------------------------------------ teacher desk */
/* ------------------------------------------------------------ teacher desk */
function deepUrl(worldId, i) {
  return location.href.split("?")[0].split("#")[0] + "?world=" + encodeURIComponent(worldId) + "&spread=" + i;
}
function qrSvg(text) {
  try {
    const q = qrcode(0, "M"); q.addData(text); q.make();
    return q.createSvgTag({ cellSize: 4, margin: 2 }).replace("<svg", '<svg width="112" height="112"');
  } catch (e) { return `<div class="muted" data-i18n="ui.qrUnavailable">${esc(uiTxt("ui.qrUnavailable"))}</div>`; }
}
function screenTeacher() {
  const w = EV.world || getWorld("c9_matter");
  const rows = w.spreads.map((sp, i) => {
    const p = EV.progress[pkey(w, sp)] || {};
    return `<tr><td>${i + 1}</td><td><b>${esc(sp.title)}</b><small>${esc(sp.section)} · ${esc(sp.scene.type)}</small></td>
      <td class="ctr">${p.locked ? "✓" : "—"}</td><td class="ctr">${p.touched || 0}</td>
      <td class="ctr">${p.challengeOK ? "✓" : "—"}</td><td class="ctr">${p.stamped ? "★" : "—"}</td></tr>`;
  }).join("");
  const qrs = w.spreads.map((sp, i) => `<div class="qr-card"><div class="qr-svg">${qrSvg(deepUrl(w.id, i))}</div>
    <b>${i + 1}. ${esc(sp.short)}</b><small data-i18n="scan">${esc(t("scan"))}</small><code>${esc(deepUrl(w.id, i).split("?")[1])}</code></div>`).join("");
  return screenHead(t("teacherTitle"), t("teacherSub"),
    `<button class="btn ghost" id="btnExportCsv" data-i18n="exportCsv">${esc(t("exportCsv"))}</button>`, "teacherTitle", "teacherSub") + `
  <div class="grid2">
    <div class="card"><div class="card-head"><b data-i18n="progressTable">${esc(t("progressTable"))}</b><span>${stampsFor(w)} / ${w.spreads.length} ${esc(t("stamp"))}</span></div>
      <table class="progress-table"><thead><tr><th>#</th><th data-i18n="spread">${esc(t("spread"))}</th><th data-i18n="locked">${esc(t("locked"))}</th><th data-i18n="touched">${esc(t("touched"))}</th><th data-i18n="challengeCol">${esc(t("challengeCol"))}</th><th data-i18n="stampCol">${esc(t("stampCol"))}</th></tr></thead><tbody>${rows}</tbody></table>
      <div class="row"><button class="btn ghost" id="btnExportSpec2" data-i18n="exportSpecBtn">${esc(t("exportSpecBtn"))}</button><span class="hint" data-i18n="ui.progressLocal">${esc(uiTxt("ui.progressLocal"))}</span></div>
    </div>
    <div class="card"><div class="card-head"><b data-i18n="arTitle">${esc(t("arTitle"))}</b></div>
      <p class="hint" style="font-size:11.5px" data-i18n="arBody">${esc(t("arBody"))}</p>
      <div class="arch-mini"><span data-i18n="ui.workflow">${esc(uiTxt("ui.workflow"))}</span></div>
    </div>
  </div>
  <div class="card"><div class="card-head"><b data-i18n="qrTitle">${esc(t("qrTitle"))}</b><span>${w.spreads.length} <span data-i18n="ui.markers">${esc(uiTxt("ui.markers"))}</span></span></div>
    <div class="qr-grid">${qrs}</div><p class="hint" data-i18n="qrNote">${esc(t("qrNote"))}</p></div>`;
}

function bindTeacher() {
  const w = EV.world || getWorld("c9_matter");
  const csv = ["spread,section,title,scene,prediction_locked,parts_touched,challenge_met,stamped"].concat(
    w.spreads.map((sp, i) => {
      const p = EV.progress[pkey(w, sp)] || {};
      return [i + 1, sp.section, '"' + String(sp.title).replace(/"/g, '""') + '"', sp.scene.type,
        p.locked ? 1 : 0, p.touched || 0, p.challengeOK ? 1 : 0, p.stamped ? 1 : 0].join(",");
    })).join("\n");
  $("btnExportCsv").onclick = () => {
    const b = new Blob([csv], { type: "text/csv" }), u = URL.createObjectURL(b);
    const a = document.createElement("a"); a.href = u; a.download = "eduverse-progress.csv"; a.click();
    setTimeout(() => URL.revokeObjectURL(u), 1500); toast(t("saved"));
  };
  $("btnExportSpec2").onclick = () => download("world-spec.json", JSON.stringify(w, null, 2));
}

function bindCompiler() {
  const ta = $("compileText");
  ta.addEventListener("input", () => EVFSM.transition("compiler", "INPUT", {}));
  $("btnLoadSample").onclick = () => { EVFSM.transition("compiler", "INPUT", {});
    const s = `Carbon and its Compounds — NCERT Science Class X, Chapter 4\n\nCarbon has atomic number 6 and electronic configuration 2,4. It cannot gain or lose four electrons, so it shares four valence electrons to form covalent bonds. Covalent compounds have low melting and boiling points and are poor conductors of electricity.\n\nTetravalency and catenation give rise to millions of carbon compounds. Saturated hydrocarbons contain only single bonds, while unsaturated hydrocarbons contain double or triple bonds. Chains may be straight, branched or arranged in rings, giving structural isomers.\n\nA homologous series has the same functional group and successive members differ by a CH2 unit of 14 u. Functional groups such as alcohol, aldehyde, ketone and carboxylic acid decide the chemical properties.\n\nCarbon compounds burn in oxygen to give carbon dioxide, water, heat and light. Ethanol is oxidised to ethanoic acid by alkaline potassium permanganate. Unsaturated hydrocarbons add hydrogen in the presence of nickel catalyst, while methane and chlorine undergo substitution in sunlight.\n\nEthanoic acid reacts with sodium carbonate to release carbon dioxide. It reacts with ethanol in the presence of an acid catalyst to form a sweet smelling ester. Soap molecules form micelles with hydrophobic tails and hydrophilic heads, but hard water forms scum while detergents remain effective.`;
    ta.value = s; toastKey("toast.sample", "Sample chapter loaded");
  };
  $("btnClearCompile").onclick = () => { EVFSM.transition("compiler", "CLEAR", {}); ta.value = ""; html($("compileReport"), `<span class="muted" data-i18n="ready">${esc(t("ready"))}</span>.`); html($("compileJson"), `<span data-i18n="ui.compiledPlaceholder">${esc(uiTxt("ui.compiledPlaceholder"))}</span>`); $("btnBuildWorld").disabled = true; };
  $("fileInput").onchange = async e => {
    const f = e.target.files[0]; if (!f) return;
    if (/\.pdf$/i.test(f.name)) { const buf = await f.arrayBuffer(); ta.value = extractPdfText(buf); toastKey("toast.pdf", "PDF text extracted locally (best effort)"); }
    else if (/\.json$/i.test(f.name)) { try { EVFSM.transition("compiler", "IMPORT", {}); EV.compiled = normalizeWorld(JSON.parse(await f.text())); showCompiled(EV.compiled); toastKey("toast.worldspec", "WorldSpec imported"); } catch (err) { toast(uiTxt("toast.invalidJson") + err.message, "warn"); } }
    else { ta.value = await f.text(); toast(f.name + " " + uiTxt("toast.fileLoaded")); }
  };
  $("btnCompile").onclick = () => {
    const text = ta.value.trim();
    if (text.length < 80) { toastKey("toast.chars", "Paste at least 80 characters of chapter text", "warn"); return; }
    EVFSM.transition("compiler", "COMPILE", { length: text.length });
    EV.compiled = compileChapter(text, {
      title: $("compileTitle").value.trim() || undefined, cls: $("compileCls").value,
      subject: $("compileSubject").value, source: "Uploaded textbook chapter"
    });
    showCompiled(EV.compiled);
  };
  $("btnCopySpec").onclick = () => { if (EV.compiled) { navigator.clipboard && navigator.clipboard.writeText(JSON.stringify(EV.compiled, null, 2)); toast(t("copied")); } };
  $("btnBuildWorld").onclick = () => {
    if (!EV.compiled) return;
    EVFSM.transition("compiler", "BUILD", { compiled: !!EV.compiled });
    EV.world = EV.compiled;
    EV.extraChapters = EV.extraChapters.filter(c => c.id !== EV.world.id);
    EV.extraChapters.push({ id: EV.world.id, title: EV.world.title, color: EV.world.color, source: "compiled", world: EV.world });
    WORLD.setWorld(EV.world, 0); renderTop(); renderChapterList(); setView("book"); flash();
    toast(t("compiled") + " · " + EV.world.spreads.length + " " + t("spreads"), "ok");
  };
  if (EV.compiled) showCompiled(EV.compiled);
}
function showCompiled(w) {
  const rep = validateWorld(w);
  const rows = rep.map(r => `<div class="rep-row ${r.status}"><b>${r.status === "pass" ? "✓" : "!"}</b><span>${esc(r.name)}</span><small>${esc(r.msg)}</small></div>`).join("");
  html($("compileReport"), rows);
  $("compileCount").textContent = `${w.stats.characters} ${t("chars")} · ${w.spreads.length} ${t("spreads")} · ${esc(w.stats.detectedChapter || "generic")}`;
  /* `<pre data-i18n="ui.compiledPlaceholder">` is translated on first render.
     Once real WorldSpec JSON exists, drop that key: EVDICT.apply() would
     otherwise overwrite the entire generated spec with the placeholder. */
  const jsonNode = $("compileJson");
  if (jsonNode) {
    jsonNode.removeAttribute("data-i18n");
    jsonNode.textContent = JSON.stringify(w, null, 2);
  }
  $("btnBuildWorld").disabled = false;
  toast(`${t("compiled")}: ${w.spreads.length} ${t("spreads")}`, "ok");
}
function extractPdfText(buf) {
  const bytes = new Uint8Array(buf);
  let raw = ""; for (let i = 0; i < bytes.length; i++) raw += String.fromCharCode(bytes[i]);
  const out = [];
  const re = /\(((?:\\.|[^\\)])*)\)\s*Tj|\[((?:[^\]]|\\.)*)\]\s*TJ/g;
  let m;
  while ((m = re.exec(raw)) !== null && out.length < 900) {
    if (m[1] !== undefined) out.push(m[1]);
    else { const parts = m[2].match(/\(((?:\\.|[^\\)])*)\)/g) || []; parts.forEach(p => out.push(p.slice(1, -1))); }
  }
  let text = out.join(" ").replace(/\\[nrt]/g, " ").replace(/\\(\d{3})/g, (a, b) => String.fromCharCode(parseInt(b, 8))).replace(/[^\x20-\x7E\u0900-\u097F\n]/g, " ").replace(/\s+/g, " ").trim();
  if (text.length < 120) {
    text = (raw.match(/[A-Za-z\u0900-\u097F][A-Za-z\u0900-\u097F ,.;:'"()\-]{18,}/g) || []).slice(0, 400).join(" ");
  }
  return text.slice(0, 60000);
}
function bindSpec() {
  $("btnDownloadSpec").onclick = () => download("world-spec.json", $("specText").value);
  $("btnPrompt").onclick = () => { navigator.clipboard && navigator.clipboard.writeText(GEMINI_PROMPT); toast(t("copied")); };
  $("specFile").onchange = async e => { const f = e.target.files[0]; if (f) { $("specText").value = await f.text(); toastKey("toast.specLoaded", "Spec loaded"); } };
  $("btnValidateSpec").onclick = () => validateSpecUI();
  $("btnApplySpec").onclick = () => {
    let w; try { w = normalizeWorld(JSON.parse($("specText").value)); } catch (e) { toast(uiTxt("toast.jsonError") + e.message, "warn"); return; }
    const rep = validateWorld(w), bad = rep.filter(r => r.status === "review");
    if (bad.length && !confirm(`${bad.length} validator notes:\n` + bad.map(r => "• " + r.name + " — " + r.msg).join("\n") + "\n\nBuild anyway?")) return;
    EV.world = w; WORLD.setWorld(w, 0); renderTop(); renderChapterList(); setView("book"); flash();
    toast(t("compiled"), "ok");
  };
  validateSpecUI();
}
function validateSpecUI() {
  let rep;
  try { rep = validateWorld(normalizeWorld(JSON.parse($("specText").value))); }
  catch (e) { html($("specReport"), `<div class="rep-row review"><b>!</b><span data-i18n="toast.jsonError">${esc(uiTxt("toast.jsonError"))}</span><small>${esc(e.message)}</small></div>`); return; }
  html($("specReport"), rep.map(r => `<div class="rep-row ${r.status}"><b>${r.status === "pass" ? "✓" : "!"}</b><span>${esc(r.name)}</span><small>${esc(r.msg)}</small></div>`).join(""));
  toast(rep.every(r => r.status === "pass") ? t("passed") + " · " + rep.length + " " + uiTxt("ui.checks") : t("review") + " · " + rep.filter(r => r.status === "review").length + " " + uiTxt("ui.notes"));
}
function bindQuiz() {
  document.querySelectorAll(".qi-opts input").forEach(i => i.addEventListener("change", () =>
    EVFSM.transition("quiz", "ANSWER", {})));
  $("btnQuizSubmit").onclick = () => {
    const w = EV.world || getWorld("c10_carbon"), qs = QZ(w); let score = 0;
    qs.forEach((q, i) => {
      const sel = document.querySelector(`input[name="q${i}"]:checked`), v = sel ? +sel.value : -1;
      const why = $("why" + i);
      if (why) { why.hidden = false; why.className = "qi-why " + (v === q.a ? "ok" : "no"); why.innerHTML = `<b>${v === q.a ? "✓" : "✗"}</b> ${esc(q.why)}`; }
      if (v === q.a) score++;
    });
    EVFSM.transition("quiz", "COMPLETE", { answered: document.querySelectorAll(".qi-opts input:checked").length });
    $("scoreBadge").textContent = score + " / " + qs.length;
    $("quizResult").innerHTML = `<b>${esc(t("score"))}: ${score} / ${qs.length}</b>`;
    if (score === qs.length) toastKey("toast.perfect", "Perfect score ★", "ok"); else toast(`${score} / ${qs.length}`);
  };
  $("btnQuizRetry").onclick = () => {
    EVFSM.transition("quiz", "RESET", {});
    document.querySelectorAll(".qi-opts input").forEach(i => i.checked = false);
    document.querySelectorAll(".qi-why").forEach(d => { d.hidden = true; d.textContent = ""; });
    $("scoreBadge").textContent = "—"; $("quizResult").textContent = "";
  };
}

/* ----------------------------------------------------------------- WORLD glue */
const callbacks = {
  onReady() { /* keep the printed header clear on a classroom projector */ },
  onFrame() { EVRASTER.frame(); },
  onZoom() { EVZOOM.open(); },
  onView(v) { },
  onChapter(id, spread) {
    if (String(id).indexOf("sec:") === 0) {
      if (!EV.world || EV.world.id !== "c10_carbon") openChapter("c10_carbon");
      if (spread != null) WORLD.jumpTo(spread);
      return;
    }
    openChapter(id);
  },
  onPage(index, sp) {
    if (WORLD.plate2d && !WORLD.plate2dAvailable(EV.world)) { WORLD.setPlate2D(false); EVRASTER.deactivate(); }
    renderLesson(); renderMeters(); renderPageBar(); renderTop();
    if (typeof EVBIND !== "undefined") EVBIND.onSpread(index);
    if (typeof O3LAB !== "undefined") O3LAB.onSpread(index);
    if (typeof EVPROJ !== "undefined") EVPROJ.onSpread(index); },
  onRebuild(sp, params, ctrls) { renderMeters(); renderPageBar(); },
  onParam(id, value, model, source) {
    EV.lastModel = model; updateReadouts(model);
    if (typeof O3LAB !== "undefined") O3LAB.onParam(id, value, model, source);
    const inp = document.querySelector(`[data-cid="${id}"]`);
    if (inp && source !== "slider") inp.value = value;
    const w = EV.world, sp = w.spreads[WORLD.index], pg = pget(w, sp);
    if (!pg.locked && source !== "demo") { /* predict-first hint stays visible */ }
  },
  onTouch(id, label, touched, model, params) {
    EV.lastTouched = touched.size;
    pget(EV.world, EV.world.spreads[WORLD.index]).touched = touched.size;
    renderTouchDots(); updateReadouts(model);
    toast("✦ " + (label || id) + uiTxt("toast.inspected", EV.lang === "hi" ? " · जानकारी दर्ज" : " · inspected"), "ok");
    const st = WORLD.getState();
    Object.keys(st.params).forEach(k => { const inp = document.querySelector(`[data-cid="${k}"]`); if (inp) inp.value = st.params[k]; });
  },
  onReset(params, model) { renderMeters(); },
  onDemoStep(s, i, n) { const c = $("demoCaption"); if (c) { c.hidden = false; c.innerHTML = `<b>${i}/${n}</b> ${esc(s.caption || "")}`; } },
  onDemoStop: demoStopped,
  onPrecision() { },
  onShot() { syncBoardUI(); }
};

/* ------------------------------------------------------- language + projector */
function syncBoardUI() {
  const on = WORLD.getShot && WORLD.getShot() === "board";
  const stage = $("stage"); if (stage) stage.classList.toggle("projector", on);
  const b = $("btnBoard");
  if (b) {
    const key = on ? "board" : "boardExit", label = t(key);
    b.classList.toggle("active", !!on);
    b.title = label; b.setAttribute("aria-label", label);
    b.setAttribute("data-i18n-title", key); b.setAttribute("data-i18n-aria", key);
    if (typeof EVDICT !== "undefined") EVDICT.apply(b, EV.lang);
  }
}
/* ------------------------------------------------ collapsible dock panels
   Left = prediction card, right = live readings. Hiding both leaves only the
   40 px pager strip; boardFit() then expands the book automatically. */
function applyPanels() {
  const st = $("stage"); if (!st) return;
  const bothHidden = !EV.panels.left && !EV.panels.right;
  st.classList.toggle("hide-left", !EV.panels.left);
  st.classList.toggle("hide-right", !EV.panels.right);
  /* R4: use the vacant stage margins - a wider straight-on book. */
  if (typeof WORLD !== "undefined" && WORLD.setWide)
    WORLD.setWide(EV.theme === "classroom" ? (bothHidden ? 1.34 : 1.30) : (bothHidden ? 1.30 : 1.22));
  if ($("btnReader")) $("btnReader").classList.toggle("active", bothHidden);
  EVFSM.observe("panels", panelState(), "app.js:applyPanels");
  document.querySelectorAll("[data-panel]").forEach(b => {
    const k = b.dataset.panel;
    b.classList.toggle("active", k === "both" ? bothHidden : !EV.panels[k]);
  });
}
function togglePanel(which) {
  EVFSM.transition("panels", which === "both" ? "TOGGLE_BOTH" : which === "left" ? "TOGGLE_LEFT" : "TOGGLE_RIGHT", {});
  if (which === "both") {
    const show = !EV.panels.left && !EV.panels.right;
    EV.panels.left = EV.panels.right = show;
  } else if (which === "left" || which === "right") {
    EV.panels[which] = !EV.panels[which];
  } else return;
  try { localStorage.setItem("eduverse-panels-v1", JSON.stringify(EV.panels)); } catch (e) {}
  applyPanels();
  toast(!EV.panels.left && !EV.panels.right ? t("panelsHidden") : t("panelsShown"));
}
function setLanguage(mode) {
  if (LANG_MODES.indexOf(mode) < 0) return;
  EVFSM.transition("lang", "SET", { to: mode });
  EV.lang = mode;
  /* Preserve Prompt-4 body/app classes while switching only the lang-* class. */
  const appEl = $("app");
  appEl.classList.remove("lang-en", "lang-hi", "lang-both");
  appEl.classList.add("lang-" + mode);
  WORLD.setLang(mode);
  renderNav(); renderTop(); renderChapterList();
  if (window.EVLIB) EVLIB.render();
  renderLesson(); renderMeters(); renderPageBar(); renderSectionSelect();
  if (typeof EVBIND !== "undefined") EVBIND.setLang(mode);
  if (typeof O3LAB !== "undefined") O3LAB.setLang(mode);
  if (typeof EVPROJ !== "undefined") EVPROJ.onLang(mode);
  if (typeof EVLAZY !== "undefined") EVLAZY.onLang(mode);
  if (EV.view !== "world" && EV.view !== "book") { html($("screenInner"), renderScreen(EV.view)); rebindScreen(); }
  if (typeof EVDICT !== "undefined") EVDICT.apply(document, mode);
  const msg = (typeof EVDICT !== "undefined")
    ? EVDICT.get(mode === "hi" ? "toast.hiEnabled" : mode === "en" ? "toast.enEnabled" : "toast.bothEnabled", mode)
    : (mode === "hi" ? "हिंदी सक्षम" : mode === "en" ? "English enabled" : "द्विभाषी · EN + हिंदी");
  toast(msg);
}

/* ------------------------------------------------------------------- boot */
function applyBoardText(v) {
  EVFSM.transition("boardText", "SET", { to: v === "big" ? "big" : "detail" });
  EV.boardText = v === "big" ? "big" : "detail";
  if (typeof WORLD !== "undefined" && WORLD.setBoardText) WORLD.setBoardText(EV.boardText);
  const b = $("btn30ft");
  if (b) {
    b.classList.toggle("active", EV.boardText === "big");
    const key = EV.boardText === "big" ? "ui.bigBoardOn" : "ui.bigBoardOff";
    b.title = uiTxt(key); b.setAttribute("aria-label", b.title);
    b.setAttribute("data-i18n-title", key); b.setAttribute("data-i18n-aria", key);
    if (typeof EVDICT !== "undefined") EVDICT.apply(b, EV.lang);
  }
  try { localStorage.setItem("eduverse-boardtext-v1", EV.boardText); } catch (e) {}
}
function applyUltra(v) {
  EVFSM.transition("ultra", "SET", { to: !!v ? "on" : "off" });
  EV.ultra = !!v;
  if (typeof WORLD !== "undefined" && WORLD.setUltra) WORLD.setUltra(EV.ultra);
  const b = $("btn3d");
  if (b) {
    b.classList.toggle("active", EV.ultra);
    const key = EV.ultra ? "ui.ultraOn" : "ui.ultraOff";
    b.title = uiTxt(key); b.setAttribute("aria-label", b.title);
    b.setAttribute("data-i18n-title", key); b.setAttribute("data-i18n-aria", key);
    if (typeof EVDICT !== "undefined") EVDICT.apply(b, EV.lang);
  }
  try { localStorage.setItem("eduverse-ultra-v1", EV.ultra ? "1" : "0"); } catch (e) {}
}
function applyTheme(v) {
  EVFSM.transition("theme", "SET", { to: v === "studio" ? "studio" : "classroom" });
  EV.theme = v === "studio" ? "studio" : "classroom";
  document.body.dataset.theme = EV.theme;
  if (typeof WORLD !== "undefined" && WORLD.setTheme) WORLD.setTheme(EV.theme);
  if (typeof WORLD !== "undefined" && WORLD.setWide) WORLD.setWide(EV.theme === "classroom" ? 1.30 : 1.22);
  const b = $("btnTheme");
  if (b) { b.classList.toggle("active", EV.theme === "classroom"); b.textContent = EV.theme === "classroom" ? "◐" : "◑";
    const key = EV.theme === "classroom" ? "ui.highContrast" : "ui.studioTheme";
    b.title = uiTxt(key); b.setAttribute("aria-label", b.title);
    b.setAttribute("data-i18n-title", key); b.setAttribute("data-i18n-aria", key);
    if (typeof EVDICT !== "undefined") EVDICT.apply(b, EV.lang); }
  try { localStorage.setItem("eduverse-theme-v1", EV.theme); } catch (e) {}
}
function boot() {
  loadProgress();
  try { const th = localStorage.getItem("eduverse-theme-v1"); if (th === "studio") EV.theme = "studio"; } catch (e) {}
  applyTheme(EV.theme);
  try { const bt = localStorage.getItem("eduverse-boardtext-v1"); if (bt === "big") EV.boardText = "big"; } catch (e) {}
  applyBoardText(EV.boardText);
  try { EV.ultra = localStorage.getItem("eduverse-ultra-v1") === "1"; } catch (e) {}
  applyUltra(EV.ultra);
  try {
    const saved = JSON.parse(localStorage.getItem("eduverse-panels-v1") || "null");
    if (saved && typeof saved.left === "boolean" && typeof saved.right === "boolean") EV.panels = saved;
  } catch (e) {}
  EV.world = getWorld("c10_carbon");
  const qs = new URLSearchParams(location.search);
  const deepWorld = qs.get("world"), deepSpread = parseInt(qs.get("spread") || "0", 10) || 0;
  if (deepWorld && CATALOGUE_ALL.some(c => c.id === deepWorld)) EV.world = getWorld(deepWorld);
  WORLD.init($("gl"), callbacks);
  EVRASTER.install();
  $("precision2d").addEventListener("click", e => { if (e.target.closest("svg")) EVZOOM.open(); });
  WORLD.setLang(EV.lang);
  applyPanels();
  { const a = $("app"); a.classList.remove("lang-en", "lang-hi", "lang-both"); a.classList.add("lang-" + EV.lang); }
  WORLD.setWorld(EV.world, Math.max(0, Math.min(EV.world.spreads.length - 1, deepSpread)));
  /* Additive student dashboard: two class cards -> class drawer -> flipbook. */
  if (window.EVLIB) EVLIB.install();
  renderNav(); renderTop(); renderChapterList();
  renderLesson(); renderMeters(); renderPageBar(); renderSectionSelect();
  setView(qs.has("world") ? "book" : "world");
  $("langSelect").onchange = e => setLanguage(e.target.value);
  $("pageBar").addEventListener("click", e => {
    const v = e.target.closest && e.target.closest("[data-plate]");
    if (v && !v.disabled) { e.preventDefault(); e.stopPropagation(); setPlateView(v.dataset.plate); return; }
    const b = e.target.closest && e.target.closest("[data-panel]");
    if (b) { e.preventDefault(); e.stopPropagation(); togglePanel(b.dataset.panel); }
  });
  $("btnReader").onclick = () => togglePanel("both");
  $("btnBoard").onclick = () => {
    const on = WORLD.getShot() !== "board";
    EVFSM.transition("shot", "TOGGLE_BOARD", { to: on ? "board" : "explore" });
    WORLD.setShot(on ? "board" : "explore");
    syncBoardUI();
    toastKey(on ? "toast.boardOn" : "toast.boardOff",
      on ? "Straight projector view · alignment locked" : "Angled 3D view");
  };
  /* canvas text needs the embedded Devanagari font to be loaded first */
  if (document.fonts && document.fonts.ready) document.fonts.ready.then(() => { WORLD.refresh(); });
  syncBoardUI();
  /* Prompt 2 · install the generic pack / state / UI<->3D binding. Parts mode
     is opt-in (?parts=1, the ◈ Parts toggle, or a shared EVSTATE link), so the
     shipped R3-R8 default view is byte-for-byte unchanged in behaviour. */
  if (typeof EVBIND !== "undefined") {
    EVBIND.install();
    EVBIND.onChapter(EV.world.id, WORLD.index);
  }
  /* Prompt 3 · canonical O3 ray lab. Opt-in (?o3=1 or the ◉ O3 toggle), so
     the shipped R3-R8 default view is unchanged. It uses the SAME WORLD
     selectionRoot / shared WebGLRenderer as Prompt 2, never a second canvas. */
  if (typeof O3LAB !== "undefined") {
    O3LAB.install();
    O3LAB.onChapter(EV.world.id, WORLD.index);
  }
  /* Prompt 4 · Projector Mode + canonical dictionary. Opt-in (?projector=1,
     the ▦ toggle or Alt+P), OFF by default. It only changes DOM/CSS state and
     never creates another WebGLRenderer, canvas, rAF or state-machine fork. */
  if (typeof EVPROJ !== "undefined") {
    EVPROJ.install();
    EVPROJ.onLang(EV.lang);
  }
  /* Prompt 5 · all 29 chapter packs stay inert JSON until a chapter needs them.
     ?pack=1 / Alt+K opens the opt-in panel; default classroom view unchanged. */
  if (typeof EVLAZY !== "undefined") {
    EVLAZY.install();
    EVLAZY.onChapter(EV.world.id);
  }
  if (typeof EVDICT !== "undefined") EVDICT.apply(document, EV.lang);
  if ($("btnTheme")) $("btnTheme").onclick = () => {
    applyTheme(EV.theme === "classroom" ? "studio" : "classroom");
  };
  if ($("btn3d")) $("btn3d").onclick = () => {
    applyUltra(!EV.ultra);
    toastKey(EV.ultra ? "toast.ultraOn" : "toast.ultraOff",
      EV.ultra ? "ULTRA 3D चालू — मॉडल पन्ने से ऊपर उठा" : "3D मॉडल पन्ने पर · live render on the page");
  };
  $("btn30ft").onclick = () => {
    applyBoardText(EV.boardText === "big" ? "detail" : "big");
    toastKey(EV.boardText === "big" ? "toast.bigOn" : "toast.bigOff",
      EV.boardText === "big" ? "30 FT / बड़ा बोर्ड चालू — पिछली पंक्ति से पढ़ें" : "विस्तृत पाठ · detail plate");
  };
  if ($("btnCompileTop")) $("btnCompileTop").onclick = () => setView("compiler");
  $("btnEnter").onclick = () => { if (!EV.world) EV.world = getWorld("c10_carbon"); setView("book"); };
  if ($("btnEnterShelf")) $("btnEnterShelf").onclick = $("btnEnter").onclick;
  $("btnHelp").onclick = showHelp;
  $("btnHome").onclick = goHome;
  if ($("btnHomeFloat")) $("btnHomeFloat").onclick = goHome;
  if ($("brand")) $("brand").onclick = goHome;
  document.addEventListener("keydown", e => {
    if (e.altKey && (e.key === "h" || e.key === "H")) { e.preventDefault(); goHome(); }
  });
  $("btnBookTop").onclick = () => setView("book");
  $("btnQuizTop").onclick = () => setView("quiz");
  $("btnShotTop").onclick = () => { const n = WORLD.getShot() === "read" ? "explore" : "read";
    EVFSM.transition("shot", "TOGGLE_READ", { to: n }); WORLD.setShot(n); toast(n === "read" ? t("readShot") : t("exploreShot")); };
  $("btnFocus").onclick = () => { $("stage").classList.toggle("focus");
    EVFSM.observe("focus", $("stage").classList.contains("focus") ? "on" : "off", "app.js:btnFocus"); $("btnFocus").classList.toggle("active", $("stage").classList.contains("focus")); };
  $("btnTools").onclick = () => { const d = $("toolsDrawer"); d.hidden = !d.hidden;
    EVFSM.observe("toolsDrawer", d.hidden ? "closed" : "open", "app.js:btnTools"); $("btnTools").classList.toggle("active", !d.hidden); };
  $("btnCloseTools").onclick = () => { $("toolsDrawer").hidden = true;
    EVFSM.observe("toolsDrawer", "closed", "app.js:btnCloseTools"); $("btnTools").classList.remove("active"); };
  /* R8 · live mirrors, atomic-restore adapters and the state capsule -------- */
  EVFSM.mirror("view", () => EV.view);
  EVFSM.mirror("shot", () => WORLD.getShot());
  EVFSM.mirror("theme", () => EV.theme);
  EVFSM.mirror("lang", () => EV.lang);
  EVFSM.mirror("boardText", () => EV.boardText);
  EVFSM.mirror("ultra", () => EV.ultra ? "on" : "off");
  EVFSM.mirror("figureMode", () => WORLD.plate2d ? "plate2d" : WORLD.figureMode);
  EVFSM.mirror("panels", () => panelState());
  EVFSM.mirror("precision", () => EV.precision ? "on" : "off");
  EVFSM.mirror("navigation", () => (EV.world ? EV.world.id : "c10_carbon") + "::" + WORLD.index);
  EVFSM.mirror("demo", () => EV.demo ? "running" : "idle");
  EVFSM.mirror("toolsDrawer", () => $("toolsDrawer") && $("toolsDrawer").hidden ? "closed" : "open");
  EVFSM.mirror("focus", () => $("stage") && $("stage").classList.contains("focus") ? "on" : "off");
  EVFSM.mirror("pageTurn", () => WORLD.turning ? "turning" : "idle");
  EVFSM.context(() => ({
    view: EV.view, dom: { screenHidden: $("screen") ? $("screen").hidden : null },
    toolView: ["compiler", "spec", "quiz", "research", "teacher"].indexOf(EV.view) >= 0,
    worldTheme: EV.theme, classroom: EV.theme === "classroom",
    plate2dAvailable: !!(EV.world && WORLD.plate2dAvailable(EV.world)),
    wide: (typeof WORLD !== "undefined" && WORLD.wide) || 1.30,
    audit: WORLD.boardAudit ? WORLD.boardAudit() : null,
    subjectBio: !!(EV.world && (EV.world.subject === "bio" || EV.world.subject === "Biology")),
    known: !!(EV.world && CATALOGUE_ALL.some(c => c.id === EV.world.id)),
    count: EV.world ? EV.world.spreads.length : 0,
    capsule: null, drifts: []
  }));
  EVFSM.adapter("view", v => setView(v));
  EVFSM.adapter("shot", v => WORLD.setShot(v));
  EVFSM.adapter("theme", v => applyTheme(v));
  EVFSM.adapter("lang", v => setLanguage(v));
  EVFSM.adapter("boardText", v => applyBoardText(v));
  EVFSM.adapter("ultra", v => applyUltra(v === "on"));
  EVFSM.adapter("figureMode", v => {
    if (v === "plate2d" && EV.world && WORLD.plate2dAvailable(EV.world)) {
      WORLD.setPlate2D(true);
      EVFSM.observe("figureMode", "plate2d", "app.js:figureModeAdapter");
    } else {
      WORLD.setPlate2D(false);
      WORLD.setFigureMode(v === "plate2d" ? "3d" : v);
    }
  });
  EVFSM.adapter("panels", v => {
    EV.panels.left = v !== "reader" && v !== "leftHidden";
    EV.panels.right = v !== "reader" && v !== "rightHidden";
    try { localStorage.setItem("eduverse-panels-v1", JSON.stringify(EV.panels)); } catch (e) {}
    applyPanels();
  });
  EVFSM.adapter("precision", v => { EV.precision = (v === "on"); applyPrecision(); });
  EVFSM.adapter("navigation", v => {
    const parts = String(v).split("::"), id = parts[0], idx = parseInt(parts[1], 10) || 0;
    if (!EV.world || EV.world.id !== id) {
      if (!CATALOGUE_ALL.some(c => c.id === id)) return;
      EV.world = getWorld(id); WORLD.setWorld(EV.world, idx);
      renderTop(); renderChapterList();
    } else WORLD.jumpTo(idx);
  });
  /* The exact teaching setup can be shared as one URL param. */
  const capsule = qs.get("state");
  ["view", "shot", "theme", "lang", "boardText", "ultra", "figureMode", "panels", "precision", "navigation"]
    .forEach(id => EVFSM.observe(id, EVFSM.mirrorValue ? EVFSM.mirrorValue(id) : ({
      view: EV.view, shot: WORLD.getShot(), theme: EV.theme, lang: EV.lang,
      boardText: EV.boardText, ultra: EV.ultra ? "on" : "off",
      figureMode: WORLD.plate2d ? "plate2d" : WORLD.figureMode, panels: panelState(),
      precision: EV.precision ? "on" : "off",
      navigation: (EV.world ? EV.world.id : "c10_carbon") + "::" + WORLD.index
    })[id], "app.js:boot"));
  EVFSM.transition("persistence", "APPLY", {});
  if (capsule) {
    const cap = EVFSM.decode(capsule);
    const rr = EVFSM.restore(cap);
    /* A reviewed 2D chapter may arrive AFTER navigation in a shared capsule. */
    if (cap && cap.machines && cap.machines.figureMode === "plate2d" &&
        WORLD.plate2dAvailable(EV.world)) {
      WORLD.setPlate2D(true);
      EVFSM.observe("figureMode", "plate2d", "app.js:capsulePlate2D");
      renderPageBar();
    }
    if (rr.ok) toastKey("toast.restore", "Shared board setup restored", "ok");
  }
  /* Alt+R = known-good projector preset; Alt+S = copy a shareable state link. */
  window.addEventListener("keydown", e => {
    if (!e.altKey) return;
    if (e.key === "r" || e.key === "R") { e.preventDefault(); EVFSM.preset("classroom");
      toastKey("toast.preset", "Classroom projector preset applied", "ok"); }
    if (e.key === "s" || e.key === "S") { e.preventDefault();
      const url = location.origin + EVFSM.link(location.href);
      if (navigator.clipboard) navigator.clipboard.writeText(url).catch(() => {});
      toastKey("toast.share", "Shareable board link copied", "ok"); }
  });
  window.addEventListener("resize", () => WORLD.resize());
  /* swipe to turn pages */
  let sx = null;
  $("gl").addEventListener("touchstart", e => { sx = e.touches[0].clientX; }, { passive: true });
  $("gl").addEventListener("touchend", e => {
    if (sx === null || EV.view !== "book") return;
    const dx = e.changedTouches[0].clientX - sx; sx = null;
    if (Math.abs(dx) > 70) WORLD.startTurn(dx < 0 ? 1 : -1);
  }, { passive: true });
}
function rebindScreen() { if (EV.view === "compiler") bindCompiler(); if (EV.view === "spec") bindSpec(); if (EV.view === "quiz") bindQuiz(); if (EV.view === "teacher") bindTeacher(); }
function showHelp() {
  const K = k => `<span data-i18n="${esc(k)}">${esc(uiTxt(k))}</span>`;
  const box = document.createElement("div");
  box.className = "modal"; box.innerHTML = `<div class="modal-inner"><button class="modal-close" title="${esc(uiTxt("ui.close"))}" data-i18n-title="ui.close" data-i18n-aria="ui.close">×</button>
    <div class="eyebrow">${K("ui.helpEyebrow")}</div><h2>${K("ui.helpTitle")}</h2>
    <ol><li><b>${K("ui.helpMetaWorld")}</b> — ${K("ui.help1")}</li>
    <li><b>${K("ui.helpRealBook")}</b> — ${K("ui.help2")}</li>
    <li><b>${K("ui.helpPopUp")}</b> — ${K("ui.help3")}</li>
    <li><b>${K("ui.helpPredictFirst")}</b> — ${K("ui.help4")}</li>
    <li><b>${K("ui.helpExperiment")}</b> — ${K("ui.help5")}</li>
    <li><b>${K("ui.helpChallengeStamp")}</b> — ${K("ui.help6")}</li>
    <li><b>${K("ui.helpCompiler")}</b> — ${K("ui.help7")}</li></ol>
    <p class="muted">${K("ui.helpSyllabus")}</p>
    <p class="muted"><b data-i18n="ui.credit">${esc(uiTxt("ui.credit"))}</b> · ${K("ui.helpCredit")}</p>
    <p class="muted"><b>▣ ${K("ui.straightView")}</b> — ${K("ui.helpProjector")}</p>
    <p class="muted"><b>${K("ui.langBoth")} / ${K("ui.langHi")} / ${K("ui.langEn")}</b> — ${K("ui.helpLanguage")}</p></div>`;
  document.body.appendChild(box);
  if (typeof EVDICT !== "undefined") EVDICT.apply(box, EV.lang);
  box.querySelector(".modal-close").onclick = () => box.remove();
  box.onclick = e => { if (e.target === box) box.remove(); };
}

/* ==========================================================================
   EVLIB — ACADEMIC LIBRARY DASHBOARD (additive, world view only)
   --------------------------------------------------------------------------
   Two separately clickable Class IX / Class X textbook cards built from the
   existing CATALOGUE_ALL + STUDENT_CHAPTERS data. A class opens that class's
   chapter drawer; a chapter calls the ORIGINAL openChapter(), so the flipbook,
   page-turn physics, 3D scenes and every QA contract are untouched.
   No new script block, no network, no image/font/GLB asset, no new renderer.
   Copyright / Developer : Paras Pranav
   ========================================================================== */
const EVLIB = (function () {
  'use strict';
  const KEYS = [
    ["lib.eyebrow", "EDUVERSE · CBSE / NCERT SCIENCE · 2026-27", "एडूवर्स · सीबीएसई / NCERT विज्ञान · 2026-27", "EDUVERSE · CBSE / NCERT SCIENCE · 2026-27"],
    ["lib.title", "Your Science Library", "आपका विज्ञान पुस्तकालय", "Your Science Library / आपका विज्ञान पुस्तकालय"],
    ["lib.sub", "Two classes · 26 chapters · one bilingual 3D flipbook. Choose a textbook to see what is inside.",
      "दो कक्षाएँ · 26 अध्याय · एक द्विभाषी 3D फ़्लिपबुक। अंदर क्या है, देखने के लिए किताब चुनें।",
      "Two classes / दो कक्षाएँ · 26 chapters · bilingual 3D flipbook"],
    ["lib.shelf", "Explore 3D shelf ↗", "3D शेल्फ देखें ↗", "Explore 3D shelf ↗ / 3D शेल्फ"],
    ["lib.textbook", "TEXTBOOK · NCERT EXPLORATION", "पाठ्यपुस्तक · NCERT अन्वेषण", "TEXTBOOK · NCERT EXPLORATION IX"],
    ["lib.textbookX", "TEXTBOOK · NCERT SCIENCE", "पाठ्यपुस्तक · NCERT विज्ञान", "TEXTBOOK · NCERT SCIENCE X"],
    ["lib.classIX", "Class IX", "कक्षा IX", "Class IX"],
    ["lib.classX", "Class X", "कक्षा X", "Class X"],
    ["lib.classIXHi", "Science · NCERT Exploration IX", "विज्ञान · NCERT अन्वेषण IX", "कक्षा IX · विज्ञान · NCERT अन्वेषण"],
    ["lib.classXHi", "Science · NCERT Rationalised X", "विज्ञान · NCERT परिमार्जित X", "कक्षा X · विज्ञान · NCERT"],
    ["lib.inside", "INSIDE THIS BOOK", "इस किताब के अंदर", "INSIDE THIS BOOK / इस किताब के अंदर"],
    ["lib.open", "Open Class IX", "कक्षा IX खोलें", "Open Class IX / कक्षा IX खोलें"],
    ["lib.openX", "Open Class X", "कक्षा X खोलें", "Open Class X / कक्षा X खोलें"],
    ["lib.openIX", "Open the Class IX chapter list", "कक्षा IX की अध्याय सूची खोलें", "Open Class IX chapters / कक्षा IX के अध्याय"],
    ["lib.openXAria", "Open the Class X chapter list", "कक्षा X की अध्याय सूची खोलें", "Open Class X chapters / कक्षा X के अध्याय"],
    ["lib.note", "Pick a class → choose a chapter → the printed page and its 3D experiment open together.",
      "कक्षा चुनें → अध्याय चुनें → मुद्रित पृष्ठ और उसका 3D प्रयोग साथ खुलते हैं।",
      "Class → chapter → printed page + 3D experiment / कक्षा → अध्याय → पृष्ठ + 3D प्रयोग"],
    ["lib.resume", "Open book →", "किताब खोलें →", "Open book →"],
    ["lib.back", "← Both classes", "← दोनों कक्षाएँ", "← Both classes / दोनों कक्षाएँ"],
    ["lib.backShelf", "← Library dashboard", "← पुस्तकालय डैशबोर्ड", "← Library / पुस्तकालय"],
    ["lib.close", "Close chapter list", "अध्याय सूची बंद करें", "Close / बंद करें"],
    ["lib.drawerIX", "Class IX · Chapters", "कक्षा IX · अध्याय", "Class IX · Chapters / कक्षा IX · अध्याय"],
    ["lib.drawerX", "Class X · Chapters", "कक्षा X · अध्याय", "Class X · Chapters / कक्षा X · अध्याय"],
    ["lib.drawerEyebrow", "NCERT SCIENCE · CHOOSE A CHAPTER", "NCERT विज्ञान · अध्याय चुनें", "NCERT SCIENCE · CHOOSE A CHAPTER"],
    ["lib.statClasses", "Classes", "कक्षाएँ", "Classes"],
    ["lib.statChapters", "Chapters", "अध्याय", "Chapters"],
    ["lib.statSpreads", "Spreads", "स्प्रेड", "Spreads"],
    ["lib.chapters", "chapters", "अध्याय", "chapters"],
    ["lib.spreads", "spreads", "स्प्रेड", "spreads"],
    ["lib.bilingualLabel", "Bilingual EN + Hindi", "द्विभाषी EN + हिंदी", "EN + हिंदी"],
    ["lib.footReady", "chapters ready · click any row to open the flipbook",
      "अध्याय तैयार · फ़्लिपबुक खोलने के लिए किसी पंक्ति पर क्लिक करें",
      "chapters ready · click a row to open the flipbook"]
  ];
  const SUBJ = {
    chem: ["Chemistry", "रसायन विज्ञान"], bio: ["Biology", "जीव विज्ञान"],
    phy: ["Physics", "भौतिक विज्ञान"], science: ["Science", "विज्ञान"],
    earth: ["Earth", "पृथ्वी"]
  };
  let cls = null;
  let installed = false;

  if (typeof EVDICT !== "undefined") KEYS.forEach(k => EVDICT.register(k[0], k[1], k[2], k[3]));

  const K = key => 'data-i18n="' + esc(key) + '"';
  const A = (en, hi) => 'data-i18n="' + esc((typeof EVDICT !== "undefined") ? EVDICT.auto(en, hi) : String(en)) + '"';
  const text = (en, hi) => (typeof EVDICT !== "undefined") ? EVDICT.get(EVDICT.auto(en, hi), EV.lang) : BI(en, hi);
  const rowsFor = c => CATALOGUE_ALL.filter(x => x.cls === c && STUDENT_CHAPTERS.indexOf(x.id) >= 0);
  const nSpreads = c => (typeof WORLDS !== "undefined" && WORLDS[c.id]) ? WORLDS[c.id].length : 0;
  const subj = c => SUBJ[c.subject] || SUBJ.science;

  function pill(en, hi, tone) {
    return '<span class="lp-pill ' + (tone || '') + '" ' + A(en, hi) + '>' + esc(text(en, hi)) + '</span>';
  }
  function render() {
    if (!installed) return;
    const ix = rowsFor("IX"), x = rowsFor("X");
    const totalSpreads = ix.concat(x).reduce((n, c) => n + nSpreads(c), 0);
    const stat = (n, keyName) => '<span class="lib-stat"><b>' + n + '</b><small ' + K(keyName) + '>' +
      esc((typeof EVDICT !== "undefined") ? EVDICT.get(keyName, EV.lang) : keyName) + '</small></span>';
    html($("libStats"), stat(2, "lib.statClasses") + stat(ix.length + x.length, "lib.statChapters") + stat(totalSpreads, "lib.statSpreads"));
    [["IX", ix], ["X", x]].forEach(pair => {
      const c = pair[0], rows = pair[1];
      const spreads = rows.reduce((n, r) => n + nSpreads(r), 0);
      const subjects = {};
      rows.forEach(r => { subjects[r.subject] = 1; });
      let meta = pill(String(rows.length) + " chapters", String(rows.length) + " अध्याय", "") +
                 pill(String(spreads) + " spreads", String(spreads) + " स्प्रेड", "amber");
      const seen = {};
      Object.keys(subjects).forEach(sk => {
        const s = SUBJ[sk] || SUBJ.science;
        if (seen[s[1]]) return;
        seen[s[1]] = 1;
        meta += pill(s[0], s[1], sk === "chem" ? "" : sk === "phy" ? "amber" : "green");
      });
      html($("libMeta" + c), meta);
      html($("libPreview" + c), rows.slice(0, 3).map(r =>
        '<span ' + A(r.title, r.hi) + '>' + esc(BI(r.title, r.hi)) + '</span>').join(""));
    });
    if (cls) renderDrawer(cls);
  }
  function renderDrawer(c) {
    const rows = rowsFor(c);
    const total = rows.reduce((n, r) => n + nSpreads(r), 0);
    $("ldEyebrow").setAttribute("data-i18n", "lib.drawerEyebrow");
    $("ldTitle").setAttribute("data-i18n", c === "IX" ? "lib.drawerIX" : "lib.drawerX");
    const G = k => (typeof EVDICT !== "undefined") ? EVDICT.get(k, EV.lang) : k;
    $("ldSub").textContent = rows.length + " " + G("lib.chapters") + " · " +
      total + " " + G("lib.spreads") + " · " + G("lib.bilingualLabel");
    $("ldFoot").textContent = rows.length + " " + G("lib.footReady");
    html($("ldList"), rows.map((r, i) => {
      const s = subj(r);
      const active = EV.world && EV.world.id === r.id;
      const detail = s[0] + " · " + nSpreads(r) + " spreads";
      const detailHi = s[1] + " · " + nSpreads(r) + " स्प्रेड";
      return '<button type="button" class="ld-row' + (active ? ' active' : '') + '" data-ch="' + esc(r.id) + '">' +
        '<span class="ld-num">' + (i + 1) + '</span>' +
        '<span class="ld-body"><b ' + A(r.title, r.hi) + '>' + esc(BI(r.title, r.hi)) + '</b>' +
        '<small ' + A(detail, detailHi) + '>' + esc(text(detail, detailHi)) + '</small></span>' +
        '<span class="ld-tag ' + esc(r.subject) + '" ' + A(s[0], s[1]) + '>' + esc(text(s[0], s[1])) + '</span>' +
        '<span class="ld-arrow" aria-hidden="true">→</span></button>';
    }).join(""));
    $("ldList").querySelectorAll("[data-ch]").forEach(b => b.onclick = () => {
      const id = b.dataset.ch;
      close();
      openChapter(id);               /* ORIGINAL controller -> setView("book") */
    });
    if (typeof EVDICT !== "undefined") EVDICT.apply($("libDrawer"), EV.lang);
  }
  function open(c) {
    if (c !== "IX" && c !== "X") return;
    setLibrary(true);
    cls = c;
    renderDrawer(c);
    $("libDrawer").hidden = false;
    try { $("ldClose").focus({ preventScroll: true }); } catch (e) {}
  }
  function close() {
    cls = null;
    if ($("libDrawer")) $("libDrawer").hidden = true;
  }
  function setLibrary(on) {
    const hud = $("worldHud"); if (!hud) return;
    hud.classList.toggle("library-mode", !!on);
    hud.classList.toggle("shelf-mode", !on);
    if (!on) close();
  }
  function install() {
    if (installed) return;
    installed = true;
    const qs = new URLSearchParams(location.search);
    setLibrary(qs.get("shelf") !== "1");
    render();
    $("classCardIX").onclick = () => open("IX");
    $("classCardX").onclick = () => open("X");
    $("libShelf").onclick = () => setLibrary(false);
    $("shelfBack").onclick = () => setLibrary(true);
    $("ldClose").onclick = close;
    $("ldBack").onclick = close;
    $("libDrawer").querySelectorAll("[data-lib-close]").forEach(n => n.onclick = close);
    document.addEventListener("keydown", e => {
      if (e.key === "Escape" && $("libDrawer") && !$("libDrawer").hidden) close();
    });
  }
  return { install, render, open, close, setLibrary,
           get class() { return cls; },
           get library() { return $("worldHud") ? $("worldHud").classList.contains("library-mode") : false; } };
})();
window.EVLIB = EVLIB;

document.addEventListener("DOMContentLoaded", boot);
