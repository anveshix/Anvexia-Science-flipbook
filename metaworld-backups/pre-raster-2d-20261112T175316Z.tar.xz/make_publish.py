#!/usr/bin/env python3
"""Rebuild + repackage the static publish bundle.

Usage:  python3 make_publish.py
Output: index.html, publish/index.html, publish/_headers, publish/nginx.conf,
        eduverse-publish.zip (+ sha256)

The CSP and security headers are regenerated from the exact inline-script/style
hashes of the rebuilt index.html. The HTML remains the only runnable file.
"""
import hashlib
import json
import os
import pathlib
import re
import shutil
import subprocess
import sys
import zipfile

ROOT = pathlib.Path(__file__).resolve().parent
os.chdir(ROOT)
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))
from tools.csp import render_netlify_headers, render_nginx_conf  # noqa: E402

subprocess.run([sys.executable, "build.py"], check=True)

src = ROOT / "index.html"
dst = ROOT / "publish" / "index.html"
os.makedirs(ROOT / "publish", exist_ok=True)
shutil.copyfile(src, dst)

html = dst.read_text(encoding="utf-8")
external = re.findall(r'(?:src|href)\s*=\s*["\']https?://[^"\']+', html)
if external:
    raise SystemExit("ERROR: external references in bundle: " + repr(external[:5]))

evidence = json.loads((ROOT / "qa" / "csp_hashes.json").read_text(encoding="utf-8"))
csp = evidence["policy"]
(ROOT / "publish" / "_headers").write_text(render_netlify_headers(csp), encoding="utf-8")
(ROOT / "publish" / "nginx.conf").write_text(render_nginx_conf(csp), encoding="utf-8")

members = [
    "index.html", ".nojekyll", "_headers", "PUBLISH.md",
    "Dockerfile", "nginx.conf", "compose.yaml",
]
zpath = ROOT / "eduverse-publish.zip"
with zipfile.ZipFile(zpath, "w", zipfile.ZIP_DEFLATED, compresslevel=9) as z:
    for name in members:
        z.write(ROOT / "publish" / name, name)

digest = hashlib.sha256(dst.read_bytes()).hexdigest()
print("index.html      ", dst.stat().st_size, "bytes")
print("external refs   ", len(external))
print("sha256          ", digest)
print("strict script CSP", evidence["scriptBlocks"], "script hashes ·",
      "style unsafe-inline for dynamic DOM styles · header-only frame-ancestors")
print("headers         ", "publish/_headers + publish/nginx.conf regenerated")
print("publish package ", zpath, os.path.getsize(zpath), "bytes")
print("files           ", ", ".join(members))
