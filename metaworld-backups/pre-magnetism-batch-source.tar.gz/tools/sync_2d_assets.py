#!/usr/bin/env python3
"""Promote newly rendered JPEGs to the persistent main-app asset store.

Some workspace snapshot systems do not retain symbolic links or hardlink identity.
The main-app assets/2d folder is authoritative. Optional newly rendered source JPEGs
are copied there before staging or packaging; older duplicate sources may be absent.
Never deletes files and does not copy review contact sheets to runtime assets.
"""
from pathlib import Path
import hashlib
import shutil

ROOT = Path(__file__).resolve().parents[1]
CANON = ROOT.parent / 'eduverse_2d_assets'
for chapter, prefix in [('c10_electricity','11-'),('c10_eye','10-'),('c10_light','9-'),('c10_periodic','P-'),('c10_carbon','4-'),('c10_repro','7-'),('c9_matter','1-'),('c9_exploration','1-'),('c9_cell','2-'),('c9_tissues','3-'),('c9_motion','4-'),('c9_mixtures','5-'),('c9_forces','6-'),('c9_work_energy','7-'),('c9_atom','8-'),('c9_atomic_foundations','9-'),('c9_sound','10-'),('c9_reproduction9','11-'),('c9_diversity','12-'),('c9_earth','13-'),('c10_reactions','1-'),('c10_acids','2-'),('c10_metals','3-'),('c10_life','5-'),('c10_control','6-'),('c10_sources','S-'),('c10_sustainable','M-'),('c10_heredity','8-'),('c10_env','13-')]:
    srcdir, destdir = CANON / chapter, ROOT / 'assets' / '2d' / chapter
    destdir.mkdir(parents=True, exist_ok=True)
    srcs=list(srcdir.glob(prefix+'*.jpg'))
    if not srcs and not list(destdir.glob(prefix+'*.jpg')):
        raise SystemExit(f'Missing runtime and newly rendered images for {chapter}')
    for src in srcs:
        dest=destdir/src.name
        if dest.exists() and hashlib.sha256(src.read_bytes()).digest()==hashlib.sha256(dest.read_bytes()).digest():
            continue
        shutil.copyfile(src,dest)
        print('synced',dest.relative_to(ROOT))
